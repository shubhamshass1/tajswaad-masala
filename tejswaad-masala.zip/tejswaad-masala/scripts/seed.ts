/**
 * Seed script — populates MongoDB with the starter product catalog and
 * creates the first owner/admin login.
 *
 * Usage:
 *   npm run seed
 *
 * Requires MONGODB_URI, ADMIN_EMAIL, ADMIN_PASSWORD, ADMIN_NAME in .env.local
 */
import "dotenv/config";
import mongoose from "mongoose";
import bcrypt from "bcryptjs";
import Product from "../src/lib/models/Product";
import User from "../src/lib/models/User";
import Testimonial from "../src/lib/models/Testimonial";
import { products } from "../src/lib/data/products";
import { testimonials } from "../src/lib/data/testimonials";

async function seed() {
  const uri = process.env.MONGODB_URI;
  if (!uri) throw new Error("MONGODB_URI is not set in your environment.");

  await mongoose.connect(uri);
  console.log("Connected to MongoDB");

  // --- Products ---
  const existingProducts = await Product.countDocuments();
  if (existingProducts === 0) {
    const docs = products.map(({ _id, ...rest }) => rest);
    await Product.insertMany(docs);
    console.log(`Seeded ${docs.length} products.`);
  } else {
    console.log(`Skipping products — ${existingProducts} already exist.`);
  }

  // --- Testimonials (pre-approved so they show immediately) ---
  const existingTestimonials = await Testimonial.countDocuments();
  if (existingTestimonials === 0) {
    const docs = testimonials.map(({ _id, createdAt, ...rest }) => ({
      ...rest,
      isApproved: true,
    }));
    await Testimonial.insertMany(docs);
    console.log(`Seeded ${docs.length} testimonials.`);
  } else {
    console.log(`Skipping testimonials — ${existingTestimonials} already exist.`);
  }

  // --- Owner/Admin user ---
  const adminEmail = (process.env.ADMIN_EMAIL || "").toLowerCase();
  const adminPassword = process.env.ADMIN_PASSWORD;
  const adminName = process.env.ADMIN_NAME || "Owner";

  if (!adminEmail || !adminPassword) {
    console.warn("ADMIN_EMAIL / ADMIN_PASSWORD not set — skipping admin user creation.");
  } else {
    const existingUser = await User.findOne({ email: adminEmail });
    if (existingUser) {
      console.log(`Admin user ${adminEmail} already exists — skipping.`);
    } else {
      const passwordHash = await bcrypt.hash(adminPassword, 10);
      await User.create({ name: adminName, email: adminEmail, passwordHash, role: "owner" });
      console.log(`Created admin user: ${adminEmail}`);
    }
  }

  await mongoose.disconnect();
  console.log("Done. You can now log in at /admin/login");
}

seed().catch((err) => {
  console.error("Seed failed:", err);
  process.exit(1);
});
