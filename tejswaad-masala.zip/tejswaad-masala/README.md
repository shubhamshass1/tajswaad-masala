# Tejswaad Masala — Full-Stack Website & Admin Panel

A premium, animated e-commerce website for **Tejswaad Masala**, built with Next.js 15,
TypeScript, Tailwind CSS, Three.js, GSAP/Framer Motion, MongoDB and NextAuth.

> Owner: Neeraj Kumar · Manufacturer & Supplier of Pure & Fresh Spices ·
> Kiul, Garhara, Teghra, Begusarai, Bihar – 851126 · FSSAI 2655816159996187

---

## 1. What's included

| Area | Status |
|---|---|
| Public site — Home, About, Products, Product detail, Bulk Order, Distributor, Gallery, Testimonials, Contact, Cart, Checkout, Order Success | ✅ Fully built |
| 3D hero (rotating spice packet + floating turmeric/chilli/coriander/cumin particles), parallax, scroll animations, glassmorphism, premium loading screen | ✅ Fully built |
| Product catalog (12 categories from the brief) with weight/price variants, Add to Cart, Buy Now, WhatsApp order | ✅ Fully built |
| Cart + Checkout with COD and Razorpay, order confirmation email | ✅ Fully built |
| Admin panel (owner-only, NextAuth credentials login) — Products, Orders, Bulk Orders, Distributors, Messages, Testimonials, Gallery, Settings, Excel export, JSON backup | ✅ Fully built |
| SEO — metadata, Open Graph, JSON-LD schema, sitemap.xml, robots.txt | ✅ Fully built |
| PWA — manifest + service worker via `next-pwa` | ✅ Fully built |
| Dark/light mode, search, wishlist, filters, sticky nav, scroll-to-top, WhatsApp/Call floating buttons, newsletter, AI FAQ chat widget | ✅ Fully built |
| Product photography | 🟡 Placeholder images generated for every product/gallery slot — replace via the admin panel once you have real photos (see §6) |
| Payments / email / image upload | 🟡 Code is complete and wired end-to-end, but needs **your own** Razorpay, SMTP and Cloudinary credentials to go live (see §3) |

Nothing here is a mockup — every page, form and admin action calls a real API route backed by
Mongoose models. You only need to add your own service credentials and content.

---

## 2. Folder structure

```
tejswaad-masala/
├─ scripts/
│  └─ seed.ts                  # Seeds MongoDB with starter products + creates the owner login
├─ public/
│  ├─ images/                  # Logo (from your visiting card) + placeholder product/gallery photos
│  └─ manifest.json            # PWA manifest
├─ src/
│  ├─ app/
│  │  ├─ layout.tsx            # Root layout: fonts, SEO metadata, JSON-LD, providers
│  │  ├─ page.tsx              # Home page
│  │  ├─ sitemap.ts / robots.ts
│  │  ├─ about/  products/  bulk-order/  distributor/  gallery/  testimonials/  contact/
│  │  ├─ cart/  checkout/  order-success/
│  │  ├─ admin/                # Owner-only dashboard (protected by middleware.ts)
│  │  └─ api/                  # All backend routes (see §4)
│  ├─ components/
│  │  ├─ layout/               # Navbar, Footer, WhatsApp/Call buttons, ArchDivider (signature motif)
│  │  ├─ home/                 # Hero3D, SpicePacket3D, FloatingSpiceParticles, sections
│  │  ├─ products/             # ProductCard, ProductGrid, filters, checkout client, gallery
│  │  ├─ forms/                # Bulk order, distributor, contact, review forms
│  │  ├─ admin/                # Admin shell, sidebar, shared admin UI kit
│  │  └─ ui/                   # Button, GlassCard, SectionHeading, RevealOnScroll
│  ├─ context/                 # CartContext, WishlistContext (persisted to localStorage)
│  ├─ lib/
│  │  ├─ models/               # Mongoose schemas (see §5)
│  │  ├─ data/                 # Static seed data (products, testimonials, gallery)
│  │  ├─ mongodb.ts  auth.ts  cloudinary.ts  razorpay.ts  sendEmail.ts  utils.ts
│  ├─ middleware.ts             # Protects every /admin/* route except /admin/login
│  └─ types/index.ts            # Shared TypeScript types
├─ .env.example                 # Copy to .env.local and fill in
├─ package.json
└─ tailwind.config.ts           # Brand colours/fonts extracted from the visiting card
```

---

## 3. Local setup

```bash
# 1. Install dependencies
npm install

# 2. Copy environment variables and fill in real values
cp .env.example .env.local

# 3. Run the dev server
npm run dev
# → http://localhost:3000
```

The site **runs immediately** with the built-in static product catalog (`src/lib/data/products.ts`)
even before MongoDB is connected — that's what powers the public pages by default. Once you add
`MONGODB_URI` and run the seed script, the **admin panel** becomes fully functional for adding,
editing and removing products/orders live.

### Services you'll need to create accounts for

| Service | Used for | Required env vars |
|---|---|---|
| [MongoDB Atlas](https://cloud.mongodb.com) (free tier is enough to start) | Products, orders, forms, admin login | `MONGODB_URI` |
| NextAuth secret | Signs admin session cookies | `NEXTAUTH_SECRET` (generate with `openssl rand -base64 32`) |
| [Cloudinary](https://cloudinary.com) (free tier) | Product & gallery image uploads from the admin panel | `CLOUDINARY_CLOUD_NAME/API_KEY/API_SECRET` |
| [Razorpay](https://razorpay.com) | Online payments (UPI/cards/netbanking) | `RAZORPAY_KEY_ID/KEY_SECRET`, `NEXT_PUBLIC_RAZORPAY_KEY_ID` |
| SMTP (Gmail App Password, or any transactional provider) | Order confirmation emails | `SMTP_HOST/PORT/USER/PASS/FROM` |

### Create the first admin (owner) login

After `MONGODB_URI`, `ADMIN_EMAIL`, `ADMIN_PASSWORD` and `ADMIN_NAME` are set in `.env.local`:

```bash
npm run seed
```

This seeds the product catalog into MongoDB and creates your owner login. Sign in at
`/admin/login` with the `ADMIN_EMAIL` / `ADMIN_PASSWORD` you set. **Change this password**
after first login by editing the `User` document in MongoDB Atlas, or extend the Settings page
to support password changes.

---

## 4. API routes (all under `/api`)

| Route | Methods | Notes |
|---|---|---|
| `/api/products`, `/api/products/[id]` | GET, POST, PUT, DELETE | Public GET; writes require admin session |
| `/api/orders`, `/api/orders/[id]` | GET, POST, PUT | Anyone can POST (place order); GET/PUT admin-only |
| `/api/bulk-order`, `/api/bulk-order/[id]` | GET, POST, PUT, DELETE | Public POST (inquiry form); rest admin-only |
| `/api/distributor`, `/api/distributor/[id]` | GET, POST | Public POST (application form); GET admin-only |
| `/api/contact`, `/api/contact/[id]` | GET, POST | Public POST (contact form); GET admin-only |
| `/api/testimonials`, `/api/testimonials/[id]` | GET, POST, PUT, DELETE | Public GET (approved only) + POST; admin approves/deletes |
| `/api/gallery`, `/api/gallery/[id]` | GET, POST, DELETE | Public GET; writes admin-only |
| `/api/newsletter` | POST | Public subscribe |
| `/api/upload` | POST | Admin-only Cloudinary image upload |
| `/api/razorpay/create-order`, `/api/razorpay/verify` | POST | Payment order creation + signature verification |
| `/api/settings` | GET, PUT | Editable homepage/contact text; GET public, PUT admin-only |
| `/api/backup` | GET | Admin-only — downloads a full JSON export of every collection |
| `/api/auth/[...nextauth]` | GET, POST | NextAuth credentials login for the admin panel |

---

## 5. Database schema (MongoDB / Mongoose)

- **Product** — slug, name, category (enum of the 12 categories from the brief), description,
  images[], weightOptions[{weight, price, mrp, stock}], isBestSeller, isNew, rating, isActive
- **Order** — orderNumber, customer{name,phone,email,address,city,state,pincode}, items[],
  subtotal, shipping, total, paymentMethod (COD/Razorpay), paymentStatus, razorpayOrderId/PaymentId,
  status (Pending→Confirmed→Packed→Shipped→Delivered/Cancelled)
- **BulkOrder** — businessName, contactPerson, phone, businessType, city, productsInterested,
  estimatedQuantity, status (New/Contacted/Quoted/Closed)
- **Distributor** — fullName, phone, city, state, experience, investmentCapacity, status
- **Testimonial** — name, location, rating, message, isApproved
- **ContactMessage** — name, email, phone, subject, message, isRead
- **GalleryImage** — url, caption, category (Spices/Factory/Packaging/Team)
- **User** — name, email, passwordHash (bcrypt), role (owner/staff) — powers admin login
- **SiteSettings** — single editable document for homepage text & contact info

All schemas are in `src/lib/models/`. Full JSON shapes are also mirrored as TypeScript types in
`src/types/index.ts` for end-to-end type safety.

---

## 6. Replacing the placeholder product photos

Every product and gallery image currently shown is a generated placeholder (styled with your
brand colours) so the site looks complete out of the box. To use real photos:

1. Log into `/admin` → **Products** → edit a product → **Upload Image** (goes to Cloudinary).
2. Or, for the gallery, use **Admin → Gallery → Add Image**.
3. Static fallback images live in `public/images/products/` and `public/images/gallery/` if you'd
   rather replace the files directly and skip Cloudinary for now.

---

## 7. Deployment (Vercel — recommended)

1. Push this project to a GitHub repository.
2. Go to [vercel.com/new](https://vercel.com/new) and import the repo.
3. Add every variable from `.env.example` under **Project Settings → Environment Variables**
   (use your real MongoDB Atlas, Cloudinary, Razorpay, SMTP values — not the placeholders).
4. Set `NEXTAUTH_URL` to your production URL (e.g. `https://www.tejswaadmasala.com`).
5. Deploy. Vercel builds and hosts the Next.js app, including all API routes, automatically.
6. After the first deploy, run `npm run seed` **locally** (pointed at your production
   `MONGODB_URI`) to create the live product catalog and your admin login — or run it via a
   one-off script from a machine with Node.js installed.
7. Point your domain's DNS to Vercel (Project Settings → Domains) and update
   `NEXT_PUBLIC_SITE_URL` / `NEXTAUTH_URL` to match.

### MongoDB Atlas quick setup
1. Create a free cluster at [cloud.mongodb.com](https://cloud.mongodb.com).
2. Database Access → add a user with a strong password.
3. Network Access → allow access from `0.0.0.0/0` (or Vercel's IPs) so the app can connect.
4. Connect → Drivers → copy the connection string into `MONGODB_URI`.

### Razorpay quick setup
1. Sign up at [razorpay.com](https://razorpay.com) and complete KYC to accept live payments
   (test mode works immediately for development).
2. Settings → API Keys → generate Key ID/Secret → add to env vars.

### Cloudinary quick setup
1. Sign up at [cloudinary.com](https://cloudinary.com).
2. Dashboard shows Cloud Name, API Key, API Secret directly — copy into env vars.

---

## 8. Design notes

- **Colours** are extracted directly from the uploaded visiting card: maroon `#8B0F13`, gold
  `#C9A227`, forest green `#163A1F`, cream `#F8EEDD` (see `tailwind.config.ts`).
- **Logo**: `public/images/logo.png` is cropped and cleaned directly from your business card
  (transparent background) and used as the single source of truth for the navbar, footer, admin
  sidebar, login screen and PWA icon.
- **Signature motif**: the gold-trimmed arch divider (`components/layout/ArchDivider.tsx`) echoes
  the sweeping gold border that frames the spice photo on your original visiting card, and is used
  as a section transition instead of a generic straight or wavy divider.
- **Typography**: Playfair Display (headings), Cormorant Garamond italic (tagline/accent), Poppins
  (body) — set up via `next/font/google` in `src/app/layout.tsx`.

---

## 9. What to check before going fully live

- [ ] Replace placeholder product photos with real photography
- [ ] Set real Razorpay **live** keys (not test keys) once ready to accept real payments
- [ ] Verify SMTP sending works (test a checkout end-to-end)
- [ ] Change the admin password from the one used during seeding
- [ ] Update `NEXT_PUBLIC_SITE_URL` and `NEXTAUTH_URL` to your real domain
- [ ] Add Google Analytics ID (`NEXT_PUBLIC_GA_ID`) if you want traffic tracking
- [ ] Submit `sitemap.xml` to Google Search Console
