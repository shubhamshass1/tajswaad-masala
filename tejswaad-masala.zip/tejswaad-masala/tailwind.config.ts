import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: [
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        // Brand palette extracted from the Tejswaad visiting card
        maroon: {
          DEFAULT: "#8B0F13",
          dark: "#5C0A0D",
          light: "#A81A1F",
        },
        gold: {
          DEFAULT: "#C9A227",
          light: "#E8C874",
          dark: "#96791C",
        },
        forest: {
          DEFAULT: "#163A1F",
          dark: "#0D2413",
          light: "#245334",
        },
        cream: {
          DEFAULT: "#F8EEDD",
          dark: "#F0E2C4",
          deep: "#E9D6AE",
        },
        charcoal: "#231810",
        turmeric: "#E08B1D",
        chili: "#C1272D",
      },
      fontFamily: {
        display: ["var(--font-playfair)", "Georgia", "serif"],
        body: ["var(--font-poppins)", "system-ui", "sans-serif"],
        accent: ["var(--font-cormorant)", "serif"],
      },
      backgroundImage: {
        "arch-gradient": "linear-gradient(180deg, #8B0F13 0%, #5C0A0D 100%)",
        "gold-shimmer":
          "linear-gradient(110deg, #96791C 0%, #E8C874 45%, #C9A227 55%, #96791C 100%)",
      },
      boxShadow: {
        premium: "0 20px 60px -15px rgba(139,15,19,0.35)",
        glass: "0 8px 32px 0 rgba(35,24,16,0.15)",
        gold: "0 0 0 1px rgba(201,162,39,0.4), 0 8px 24px rgba(201,162,39,0.25)",
      },
      keyframes: {
        float: {
          "0%,100%": { transform: "translateY(0) rotate(0deg)" },
          "50%": { transform: "translateY(-18px) rotate(8deg)" },
        },
        shimmer: {
          "0%": { backgroundPosition: "-200% 0" },
          "100%": { backgroundPosition: "200% 0" },
        },
        "fade-up": {
          "0%": { opacity: "0", transform: "translateY(24px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
      },
      animation: {
        float: "float 6s ease-in-out infinite",
        shimmer: "shimmer 2.5s linear infinite",
        "fade-up": "fade-up 0.7s ease forwards",
      },
      borderRadius: {
        arch: "50% 50% 0 0 / 100% 100% 0 0",
      },
    },
  },
  plugins: [],
};
export default config;
