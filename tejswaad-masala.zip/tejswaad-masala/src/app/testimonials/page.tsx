import type { Metadata } from "next";
import { Star } from "lucide-react";
import SectionHeading from "@/components/ui/SectionHeading";
import RevealOnScroll from "@/components/ui/RevealOnScroll";
import ReviewForm from "@/components/forms/ReviewForm";
import { testimonials } from "@/lib/data/testimonials";

export const metadata: Metadata = {
  title: "Customer Testimonials",
  description: "Read what customers and business partners say about Tejswaad Masala's spices.",
};

export default function TestimonialsPage() {
  const avgRating =
    testimonials.reduce((s, t) => s + t.rating, 0) / (testimonials.length || 1);

  return (
    <div className="pt-24 pb-20 bg-cream dark:bg-charcoal min-h-screen">
      <section className="py-12 md:py-16">
        <div className="mx-auto max-w-4xl px-6 text-center">
          <SectionHeading
            eyebrow="Customer Love"
            title="What Our Customers Say"
            description="Real feedback from home cooks, restaurants and retailers who trust Tejswaad Masala."
          />
          <div className="flex items-center justify-center gap-2 -mt-6">
            <div className="flex">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star
                  key={i}
                  className="w-5 h-5"
                  fill={i < Math.round(avgRating) ? "#C9A227" : "none"}
                  color="#C9A227"
                />
              ))}
            </div>
            <span className="text-sm text-charcoal/60 dark:text-cream/60">
              {avgRating.toFixed(1)} / 5 based on {testimonials.length}+ reviews
            </span>
          </div>
        </div>
      </section>

      <section className="pb-16">
        <div className="mx-auto max-w-6xl px-6 md:px-8 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <RevealOnScroll key={t._id} delay={(i % 3) * 0.1}>
              <div className="p-6 rounded-2xl bg-white/70 dark:bg-white/5 border border-gold/20 h-full flex flex-col">
                <div className="flex mb-3">
                  {Array.from({ length: 5 }).map((_, idx) => (
                    <Star
                      key={idx}
                      className="w-4 h-4"
                      fill={idx < t.rating ? "#C9A227" : "none"}
                      color="#C9A227"
                    />
                  ))}
                </div>
                <p className="text-charcoal/75 dark:text-cream/75 text-sm leading-relaxed flex-1">
                  &ldquo;{t.message}&rdquo;
                </p>
                <div className="mt-4 pt-4 border-t border-gold/10">
                  <p className="font-display text-charcoal dark:text-cream">{t.name}</p>
                  {t.location && (
                    <p className="text-xs text-charcoal/50 dark:text-cream/50">{t.location}</p>
                  )}
                </div>
              </div>
            </RevealOnScroll>
          ))}
        </div>
      </section>

      <section className="pb-8">
        <div className="mx-auto max-w-2xl px-6 md:px-8">
          <SectionHeading eyebrow="Share Your Experience" title="Leave a Review" />
          <RevealOnScroll>
            <ReviewForm />
          </RevealOnScroll>
        </div>
      </section>
    </div>
  );
}
