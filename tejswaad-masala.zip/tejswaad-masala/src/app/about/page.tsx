import type { Metadata } from "next";
import Image from "next/image";
import { Heart, Target, Eye, ShieldCheck } from "lucide-react";
import SectionHeading from "@/components/ui/SectionHeading";
import RevealOnScroll from "@/components/ui/RevealOnScroll";
import { BUSINESS } from "@/lib/utils";

export const metadata: Metadata = {
  title: "About Us",
  description:
    "Learn the story of Tejswaad Masala — a family-run spice manufacturer in Begusarai, Bihar, dedicated to pure, fresh, ghar jaisa flavour.",
};

export default function AboutPage() {
  return (
    <div className="pt-24">
      <section className="py-16 md:py-20 bg-cream dark:bg-charcoal">
        <div className="mx-auto max-w-4xl px-6 text-center">
          <SectionHeading
            eyebrow="About Tejswaad Masala"
            title="A Family Recipe, Now a Trusted Brand"
            description="Manufacturer & Supplier of Pure & Fresh Spices, proudly based in Begusarai, Bihar."
          />
        </div>
      </section>

      <section className="pb-20 bg-cream dark:bg-charcoal">
        <div className="mx-auto max-w-6xl px-6 md:px-8 grid md:grid-cols-2 gap-14 items-center">
          <RevealOnScroll>
            <div className="relative rounded-3xl overflow-hidden shadow-premium aspect-video">
              <Image
                src="/images/products/factory.jpg"
                alt="Tejswaad Masala spice processing"
                fill
                className="object-cover"
              />
            </div>
          </RevealOnScroll>
          <RevealOnScroll delay={0.15}>
            <h3 className="font-display text-2xl text-maroon dark:text-gold-light mb-4">
              Our Story
            </h3>
            <p className="text-charcoal/75 dark:text-cream/75 leading-relaxed mb-4">
              Tejswaad Masala started in the kitchens of Kiul, Garhara, where spice blending was
              never a shortcut — it was a craft, perfected over generations. Owner Neeraj Kumar
              set out to bring that same care to a wider table: sourcing quality raw spices,
              grinding them fresh, and packing them without artificial colours or preservatives.
            </p>
            <p className="text-charcoal/75 dark:text-cream/75 leading-relaxed">
              What began as small batches for neighbours has grown into a full manufacturing
              operation supplying homes, retailers, restaurants and distributors across Bihar —
              yet every packet still carries that original promise: ghar jaisa taste.
            </p>
          </RevealOnScroll>
        </div>
      </section>

      <section className="relative bg-forest text-cream py-20">
        <div className="mx-auto max-w-6xl px-6 md:px-8 grid sm:grid-cols-2 gap-8">
          <RevealOnScroll>
            <div className="p-8 rounded-2xl bg-white/5 border border-gold/20 h-full">
              <Target className="w-8 h-8 text-gold-light mb-4" />
              <h4 className="font-display text-xl mb-3">Our Mission</h4>
              <p className="text-cream/75 leading-relaxed">
                To make pure, chemical-free spices accessible to every household and business —
                delivering consistent quality that home cooks and chefs can rely on, batch after
                batch.
              </p>
            </div>
          </RevealOnScroll>
          <RevealOnScroll delay={0.15}>
            <div className="p-8 rounded-2xl bg-white/5 border border-gold/20 h-full">
              <Eye className="w-8 h-8 text-gold-light mb-4" />
              <h4 className="font-display text-xl mb-3">Our Vision</h4>
              <p className="text-cream/75 leading-relaxed">
                To become Bihar's most trusted spice brand, and eventually a household name
                across India — known equally for authentic taste and honest business practices.
              </p>
            </div>
          </RevealOnScroll>
        </div>
      </section>

      <section className="py-20 bg-cream-dark/40 dark:bg-[#1a1108]">
        <div className="mx-auto max-w-5xl px-6 md:px-8">
          <SectionHeading eyebrow="Why Trust Us" title="Why Tejswaad Masala is Trusted" />
          <div className="grid sm:grid-cols-3 gap-6">
            <TrustCard icon={ShieldCheck} title="FSSAI Certified" text={`License No. ${BUSINESS.fssai} — fully compliant manufacturing.`} />
            <TrustCard icon={Heart} title="No Compromise on Purity" text="No artificial colours, no fillers, only real spices." />
            <TrustCard icon={Target} title="Consistent Quality" text="Same trusted taste and aroma in every single batch." />
          </div>
        </div>
      </section>
    </div>
  );
}

function TrustCard({
  icon: Icon,
  title,
  text,
}: {
  icon: typeof ShieldCheck;
  title: string;
  text: string;
}) {
  return (
    <RevealOnScroll>
      <div className="p-6 rounded-2xl bg-white/70 dark:bg-white/5 border border-gold/20 h-full text-center">
        <Icon className="w-8 h-8 text-maroon dark:text-gold-light mx-auto mb-3" />
        <h4 className="font-display text-lg text-charcoal dark:text-cream mb-2">{title}</h4>
        <p className="text-sm text-charcoal/65 dark:text-cream/65">{text}</p>
      </div>
    </RevealOnScroll>
  );
}
