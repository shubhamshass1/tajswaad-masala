"use client";

import { useEffect, useState } from "react";
import { Trash2, Mail, MailOpen } from "lucide-react";
import { PageHeader, AdminCard } from "@/components/admin/AdminUI";
import { ContactMessage } from "@/types";

export default function AdminMessagesPage() {
  const [messages, setMessages] = useState<ContactMessage[]>([]);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    const res = await fetch("/api/contact");
    const data = await res.json();
    setMessages(Array.isArray(data) ? data : []);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  async function markRead(id: string) {
    await fetch(`/api/contact/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isRead: true }),
    });
    setMessages((prev) => prev.map((m) => (m._id === id ? { ...m, isRead: true } : m)));
  }

  async function remove(id: string) {
    if (!confirm("Delete this message?")) return;
    await fetch(`/api/contact/${id}`, { method: "DELETE" });
    setMessages((prev) => prev.filter((m) => m._id !== id));
  }

  return (
    <div>
      <PageHeader title="Contact Messages" description="Messages submitted through the website contact form." />

      {loading ? (
        <p className="text-sm text-charcoal/50">Loading...</p>
      ) : messages.length === 0 ? (
        <p className="text-sm text-charcoal/50">No messages yet.</p>
      ) : (
        <div className="space-y-3">
          {messages.map((m) => (
            <AdminCard key={m._id} className="p-4 flex items-start justify-between gap-4">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  {m.isRead ? <MailOpen className="w-4 h-4 text-charcoal/40" /> : <Mail className="w-4 h-4 text-maroon" />}
                  <p className="font-medium">{m.subject}</p>
                </div>
                <p className="text-sm text-charcoal/70 mb-1">{m.message}</p>
                <p className="text-xs text-charcoal/40">
                  {m.name} · {m.phone} {m.email ? `· ${m.email}` : ""} ·{" "}
                  {new Date(m.createdAt).toLocaleDateString("en-IN")}
                </p>
              </div>
              <div className="flex gap-1 shrink-0">
                {!m.isRead && (
                  <button onClick={() => markRead(m._id)} className="p-1.5 text-forest hover:bg-forest/10 rounded-md text-xs">
                    Mark Read
                  </button>
                )}
                <button onClick={() => remove(m._id)} className="p-1.5 text-chili hover:bg-chili/10 rounded-md">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </AdminCard>
          ))}
        </div>
      )}
    </div>
  );
}
