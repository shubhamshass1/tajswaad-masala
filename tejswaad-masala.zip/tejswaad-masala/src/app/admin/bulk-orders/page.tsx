"use client";

import { useEffect, useState } from "react";
import { PageHeader, AdminCard, StatusBadge } from "@/components/admin/AdminUI";
import { BulkOrderInquiry } from "@/types";

const STATUSES = ["New", "Contacted", "Quoted", "Closed"];

export default function AdminBulkOrdersPage() {
  const [inquiries, setInquiries] = useState<BulkOrderInquiry[]>([]);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    const res = await fetch("/api/bulk-order");
    const data = await res.json();
    setInquiries(Array.isArray(data) ? data : []);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  async function updateStatus(id: string, status: string) {
    await fetch(`/api/bulk-order/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
    setInquiries((prev) => prev.map((i) => (i._id === id ? { ...i, status: status as BulkOrderInquiry["status"] } : i)));
  }

  return (
    <div>
      <PageHeader title="Bulk Order Inquiries" description="Requests from retailers, wholesalers, restaurants and distributors." />

      <AdminCard className="overflow-x-auto">
        {loading ? (
          <p className="p-6 text-sm text-charcoal/50">Loading...</p>
        ) : inquiries.length === 0 ? (
          <p className="p-6 text-sm text-charcoal/50">No bulk order inquiries yet.</p>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-charcoal/50 border-b border-gold/10">
                <th className="py-3 px-4">Business</th>
                <th className="py-3 px-4">Contact</th>
                <th className="py-3 px-4">Type</th>
                <th className="py-3 px-4">Products</th>
                <th className="py-3 px-4">Qty</th>
                <th className="py-3 px-4">Status</th>
              </tr>
            </thead>
            <tbody>
              {inquiries.map((i) => (
                <tr key={i._id} className="border-b border-gold/5">
                  <td className="py-3 px-4">
                    <p className="font-medium">{i.businessName}</p>
                    <p className="text-xs text-charcoal/50">{i.city}</p>
                  </td>
                  <td className="py-3 px-4">
                    <p>{i.contactPerson}</p>
                    <p className="text-xs text-charcoal/50">{i.phone}</p>
                  </td>
                  <td className="py-3 px-4">{i.businessType}</td>
                  <td className="py-3 px-4 max-w-[200px] truncate">{i.productsInterested}</td>
                  <td className="py-3 px-4">{i.estimatedQuantity}</td>
                  <td className="py-3 px-4">
                    <select
                      value={i.status}
                      onChange={(e) => updateStatus(i._id, e.target.value)}
                      className="text-xs border border-gold/30 rounded-md px-2 py-1"
                    >
                      {STATUSES.map((s) => (
                        <option key={s} value={s}>{s}</option>
                      ))}
                    </select>
                    <div className="mt-1"><StatusBadge status={i.status} /></div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </AdminCard>
    </div>
  );
}
