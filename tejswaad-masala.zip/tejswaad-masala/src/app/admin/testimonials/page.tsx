"use client";

import { useEffect, useState } from "react";
import { Trash2, CheckCircle2, Star } from "lucide-react";
import { PageHeader, AdminCard } from "@/components/admin/AdminUI";
import { Testimonial } from "@/types";

export default function AdminTestimonialsPage() {
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    const res = await fetch("/api/testimonials?all=true");
    const data = await res.json();
    setTestimonials(Array.isArray(data) ? data : []);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  async function approve(id: string) {
    await fetch(`/api/testimonials/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isApproved: true }),
    });
    setTestimonials((prev) => prev.map((t) => (t._id === id ? { ...t, isApproved: true } : t)));
  }

  async function remove(id: string) {
    if (!confirm("Delete this testimonial?")) return;
    await fetch(`/api/testimonials/${id}`, { method: "DELETE" });
    setTestimonials((prev) => prev.filter((t) => t._id !== id));
  }

  return (
    <div>
      <PageHeader title="Testimonials" description="Approve customer reviews before they appear on the site." />

      {loading ? (
        <p className="text-sm text-charcoal/50">Loading...</p>
      ) : testimonials.length === 0 ? (
        <p className="text-sm text-charcoal/50">No testimonials submitted yet.</p>
      ) : (
        <div className="grid sm:grid-cols-2 gap-4">
          {testimonials.map((t) => (
            <AdminCard key={t._id} className="p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} className="w-3.5 h-3.5" fill={i < t.rating ? "#C9A227" : "none"} color="#C9A227" />
                  ))}
                </div>
                <span className={`text-xs font-semibold ${t.isApproved ? "text-green-600" : "text-yellow-600"}`}>
                  {t.isApproved ? "Approved" : "Pending"}
                </span>
              </div>
              <p className="text-sm text-charcoal/75 mb-2">&ldquo;{t.message}&rdquo;</p>
              <p className="text-xs text-charcoal/50 mb-3">
                {t.name} {t.location ? `· ${t.location}` : ""}
              </p>
              <div className="flex gap-2">
                {!t.isApproved && (
                  <button
                    onClick={() => approve(t._id)}
                    className="flex items-center gap-1 text-xs text-forest font-medium hover:underline"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" /> Approve
                  </button>
                )}
                <button
                  onClick={() => remove(t._id)}
                  className="flex items-center gap-1 text-xs text-chili font-medium hover:underline"
                >
                  <Trash2 className="w-3.5 h-3.5" /> Delete
                </button>
              </div>
            </AdminCard>
          ))}
        </div>
      )}
    </div>
  );
}
