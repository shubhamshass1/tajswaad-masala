"use client";

import { useEffect, useState } from "react";
import { Package, ShoppingCart, Building2, Users, IndianRupee } from "lucide-react";
import { PageHeader, StatCard, AdminCard, StatusBadge } from "@/components/admin/AdminUI";
import { formatINR } from "@/lib/utils";
import { Order } from "@/types";

export default function AdminDashboard() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [counts, setCounts] = useState({ products: 0, bulkOrders: 0, distributors: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const [ordersRes, productsRes, bulkRes, distRes] = await Promise.all([
          fetch("/api/orders").then((r) => r.json()),
          fetch("/api/products").then((r) => r.json()),
          fetch("/api/bulk-order").then((r) => r.json()),
          fetch("/api/distributor").then((r) => r.json()),
        ]);
        setOrders(Array.isArray(ordersRes) ? ordersRes : []);
        setCounts({
          products: Array.isArray(productsRes) ? productsRes.length : 0,
          bulkOrders: Array.isArray(bulkRes) ? bulkRes.length : 0,
          distributors: Array.isArray(distRes) ? distRes.length : 0,
        });
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  const totalRevenue = orders
    .filter((o) => o.paymentStatus === "Paid" || o.paymentMethod === "COD")
    .reduce((s, o) => s + o.total, 0);
  const pendingOrders = orders.filter((o) => o.status === "Pending").length;

  return (
    <div>
      <PageHeader title="Dashboard" description="Overview of your Tejswaad Masala business." />

      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        <StatCard label="Total Orders" value={orders.length} icon={ShoppingCart} />
        <StatCard label="Pending Orders" value={pendingOrders} icon={ShoppingCart} />
        <StatCard label="Revenue (est.)" value={formatINR(totalRevenue)} icon={IndianRupee} />
        <StatCard label="Products Listed" value={counts.products} icon={Package} />
        <StatCard label="Bulk Inquiries" value={counts.bulkOrders} icon={Building2} />
        <StatCard label="Distributor Applications" value={counts.distributors} icon={Users} />
      </div>

      <AdminCard className="p-5">
        <h3 className="font-display text-lg text-charcoal mb-4">Recent Orders</h3>
        {loading ? (
          <p className="text-sm text-charcoal/50">Loading...</p>
        ) : orders.length === 0 ? (
          <p className="text-sm text-charcoal/50">No orders yet.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-charcoal/50 border-b border-gold/10">
                  <th className="py-2 pr-4">Order #</th>
                  <th className="py-2 pr-4">Customer</th>
                  <th className="py-2 pr-4">Total</th>
                  <th className="py-2 pr-4">Payment</th>
                  <th className="py-2">Status</th>
                </tr>
              </thead>
              <tbody>
                {orders.slice(0, 8).map((o) => (
                  <tr key={o._id} className="border-b border-gold/5">
                    <td className="py-2.5 pr-4 font-medium">{o.orderNumber}</td>
                    <td className="py-2.5 pr-4">{o.customer.name}</td>
                    <td className="py-2.5 pr-4">{formatINR(o.total)}</td>
                    <td className="py-2.5 pr-4">
                      <StatusBadge status={o.paymentStatus} />
                    </td>
                    <td className="py-2.5">
                      <StatusBadge status={o.status} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </AdminCard>
    </div>
  );
}
