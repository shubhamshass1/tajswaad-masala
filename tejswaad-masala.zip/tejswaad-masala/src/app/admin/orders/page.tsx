"use client";

import { useEffect, useState } from "react";
import { Download } from "lucide-react";
import { PageHeader, AdminCard, StatusBadge } from "@/components/admin/AdminUI";
import Button from "@/components/ui/Button";
import { Order, OrderStatus } from "@/types";
import { formatINR } from "@/lib/utils";

const STATUSES: OrderStatus[] = ["Pending", "Confirmed", "Packed", "Shipped", "Delivered", "Cancelled"];

export default function AdminOrdersPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<string>("All");

  async function load() {
    setLoading(true);
    const res = await fetch("/api/orders");
    const data = await res.json();
    setOrders(Array.isArray(data) ? data : []);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  async function updateStatus(id: string, status: OrderStatus) {
    await fetch(`/api/orders/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
    setOrders((prev) => prev.map((o) => (o._id === id ? { ...o, status } : o)));
  }

  async function exportToExcel() {
    const XLSX = await import("xlsx");
    const rows = orders.map((o) => ({
      OrderNumber: o.orderNumber,
      Customer: o.customer.name,
      Phone: o.customer.phone,
      Address: `${o.customer.address}, ${o.customer.city}, ${o.customer.state} - ${o.customer.pincode}`,
      Items: o.items.map((i) => `${i.name} (${i.weight}) x${i.quantity}`).join("; "),
      Subtotal: o.subtotal,
      Shipping: o.shipping,
      Total: o.total,
      PaymentMethod: o.paymentMethod,
      PaymentStatus: o.paymentStatus,
      Status: o.status,
      Date: new Date(o.createdAt).toLocaleString("en-IN"),
    }));
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Orders");
    XLSX.writeFile(wb, `tejswaad-orders-${Date.now()}.xlsx`);
  }

  const filtered = filter === "All" ? orders : orders.filter((o) => o.status === filter);

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <PageHeader title="Orders" description="View and manage all customer orders." />
        <Button variant="outline" onClick={exportToExcel}>
          <Download className="w-4 h-4" /> Export to Excel
        </Button>
      </div>

      <div className="flex flex-wrap gap-2 mb-4">
        {["All", ...STATUSES].map((s) => (
          <button
            key={s}
            onClick={() => setFilter(s)}
            className={`px-3 py-1.5 rounded-full text-xs font-medium border ${
              filter === s ? "bg-maroon text-cream border-maroon" : "border-gold/30 text-charcoal/70"
            }`}
          >
            {s}
          </button>
        ))}
      </div>

      <AdminCard className="overflow-x-auto">
        {loading ? (
          <p className="p-6 text-sm text-charcoal/50">Loading orders...</p>
        ) : filtered.length === 0 ? (
          <p className="p-6 text-sm text-charcoal/50">No orders found.</p>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-charcoal/50 border-b border-gold/10">
                <th className="py-3 px-4">Order #</th>
                <th className="py-3 px-4">Customer</th>
                <th className="py-3 px-4">Items</th>
                <th className="py-3 px-4">Total</th>
                <th className="py-3 px-4">Payment</th>
                <th className="py-3 px-4">Status</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((o) => (
                <tr key={o._id} className="border-b border-gold/5 align-top">
                  <td className="py-3 px-4 font-medium whitespace-nowrap">{o.orderNumber}</td>
                  <td className="py-3 px-4">
                    <p>{o.customer.name}</p>
                    <p className="text-xs text-charcoal/50">{o.customer.phone}</p>
                  </td>
                  <td className="py-3 px-4 max-w-xs">
                    {o.items.map((i) => (
                      <p key={`${i.productId}-${i.weight}`} className="text-xs">
                        {i.name} ({i.weight}) x{i.quantity}
                      </p>
                    ))}
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap">{formatINR(o.total)}</td>
                  <td className="py-3 px-4">
                    <p className="text-xs mb-1">{o.paymentMethod}</p>
                    <StatusBadge status={o.paymentStatus} />
                  </td>
                  <td className="py-3 px-4">
                    <select
                      value={o.status}
                      onChange={(e) => updateStatus(o._id, e.target.value as OrderStatus)}
                      className="text-xs border border-gold/30 rounded-md px-2 py-1"
                    >
                      {STATUSES.map((s) => (
                        <option key={s} value={s}>{s}</option>
                      ))}
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </AdminCard>
    </div>
  );
}
