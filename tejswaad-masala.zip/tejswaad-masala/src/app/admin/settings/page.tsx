"use client";

import { useEffect, useState } from "react";
import { Download, Save, Loader2 } from "lucide-react";
import { PageHeader, AdminCard } from "@/components/admin/AdminUI";
import Button from "@/components/ui/Button";

type Settings = {
  heroHeading: string;
  heroSubheading: string;
  heroDescription: string;
  bannerText: string;
  phonePrimary: string;
  phoneSecondary: string;
  email: string;
  address: string;
  instagram: string;
};

export default function AdminSettingsPage() {
  const [settings, setSettings] = useState<Settings | null>(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    fetch("/api/settings")
      .then((r) => r.json())
      .then(setSettings);
  }, []);

  async function handleSave() {
    if (!settings) return;
    setSaving(true);
    setSaved(false);
    await fetch("/api/settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(settings),
    });
    setSaving(false);
    setSaved(true);
  }

  function update<K extends keyof Settings>(key: K, value: string) {
    setSettings((s) => (s ? { ...s, [key]: value } : s));
  }

  async function downloadBackup() {
    const res = await fetch("/api/backup");
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `tejswaad-backup-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  if (!settings) return <p className="text-sm text-charcoal/50">Loading settings...</p>;

  return (
    <div className="space-y-6">
      <PageHeader title="Settings" description="Update site text, contact information and manage backups." />

      <AdminCard className="p-6">
        <h3 className="font-display text-lg text-charcoal mb-4">Homepage Text</h3>
        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="Hero Heading">
            <input value={settings.heroHeading} onChange={(e) => update("heroHeading", e.target.value)} className={inputClass} />
          </Field>
          <Field label="Hero Subheading">
            <input value={settings.heroSubheading} onChange={(e) => update("heroSubheading", e.target.value)} className={inputClass} />
          </Field>
          <Field label="Hero Description" full>
            <textarea rows={2} value={settings.heroDescription} onChange={(e) => update("heroDescription", e.target.value)} className={inputClass} />
          </Field>
          <Field label="Announcement Banner (optional)" full>
            <input
              placeholder="e.g. Free shipping on orders above ₹499!"
              value={settings.bannerText}
              onChange={(e) => update("bannerText", e.target.value)}
              className={inputClass}
            />
          </Field>
        </div>
      </AdminCard>

      <AdminCard className="p-6">
        <h3 className="font-display text-lg text-charcoal mb-4">Contact Information</h3>
        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="Primary Phone">
            <input value={settings.phonePrimary} onChange={(e) => update("phonePrimary", e.target.value)} className={inputClass} />
          </Field>
          <Field label="Secondary Phone">
            <input value={settings.phoneSecondary} onChange={(e) => update("phoneSecondary", e.target.value)} className={inputClass} />
          </Field>
          <Field label="Email" full>
            <input value={settings.email} onChange={(e) => update("email", e.target.value)} className={inputClass} />
          </Field>
          <Field label="Address" full>
            <textarea rows={2} value={settings.address} onChange={(e) => update("address", e.target.value)} className={inputClass} />
          </Field>
          <Field label="Instagram URL" full>
            <input value={settings.instagram} onChange={(e) => update("instagram", e.target.value)} className={inputClass} />
          </Field>
        </div>
      </AdminCard>

      <div className="flex items-center gap-3">
        <Button onClick={handleSave} disabled={saving}>
          {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />} Save Changes
        </Button>
        {saved && <span className="text-sm text-forest">Saved!</span>}
      </div>

      <AdminCard className="p-6">
        <h3 className="font-display text-lg text-charcoal mb-2">Database Backup</h3>
        <p className="text-sm text-charcoal/60 mb-4">
          Download a full JSON export of your products, orders and other data — a good habit
          before major changes. For automatic ongoing backups, enable them in your MongoDB Atlas
          dashboard.
        </p>
        <Button variant="outline" onClick={downloadBackup}>
          <Download className="w-4 h-4" /> Download Backup
        </Button>
      </AdminCard>

      <p className="text-xs text-charcoal/40">
        Note: homepage components currently render fixed copy for best performance. To make the
        text above appear live on the site, fetch <code>/api/settings</code> in those components
        the same way the admin pages fetch their data.
      </p>
    </div>
  );
}

const inputClass =
  "w-full px-3 py-2 rounded-lg border border-gold/30 focus:outline-none focus:ring-2 focus:ring-gold text-sm";

function Field({ label, children, full }: { label: string; children: React.ReactNode; full?: boolean }) {
  return (
    <div className={full ? "sm:col-span-2" : ""}>
      <label className="block text-xs font-semibold text-charcoal/70 mb-1.5">{label}</label>
      {children}
    </div>
  );
}
