"use client";

import { useState, FormEvent } from "react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import { Loader2, Lock } from "lucide-react";
import Button from "@/components/ui/Button";

export default function AdminLoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    const res = await signIn("credentials", { email, password, redirect: false });
    setLoading(false);
    if (res?.error) {
      setError("Invalid email or password.");
    } else {
      router.push("/admin");
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-maroon-dark px-6">
      <div className="w-full max-w-sm bg-cream rounded-3xl p-8 shadow-premium">
        <div className="flex flex-col items-center mb-6">
          <Image src="/images/logo.png" alt="Tejswaad Masala" width={140} height={66} className="h-14 w-auto object-contain mb-4" />
          <div className="flex items-center gap-2 text-charcoal/60 text-sm">
            <Lock className="w-4 h-4" /> Owner Admin Login
          </div>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-charcoal/70 mb-1.5">Email</label>
            <input
              required
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-2.5 rounded-lg border border-gold/30 focus:outline-none focus:ring-2 focus:ring-gold text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-charcoal/70 mb-1.5">Password</label>
            <input
              required
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-2.5 rounded-lg border border-gold/30 focus:outline-none focus:ring-2 focus:ring-gold text-sm"
            />
          </div>
          {error && <p className="text-sm text-chili">{error}</p>}
          <Button type="submit" size="lg" disabled={loading} className="w-full">
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Sign In"}
          </Button>
        </form>
        <p className="text-center text-xs text-charcoal/40 mt-6">
          This panel is restricted to the Tejswaad Masala owner account only.
        </p>
      </div>
    </div>
  );
}
