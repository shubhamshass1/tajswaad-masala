"use client";

import { useEffect, useState } from "react";
import { PageHeader, AdminCard, StatusBadge } from "@/components/admin/AdminUI";
import { DistributorApplication } from "@/types";

const STATUSES = ["New", "Reviewing", "Approved", "Rejected"];

export default function AdminDistributorsPage() {
  const [apps, setApps] = useState<DistributorApplication[]>([]);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    const res = await fetch("/api/distributor");
    const data = await res.json();
    setApps(Array.isArray(data) ? data : []);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  async function updateStatus(id: string, status: string) {
    await fetch(`/api/distributor/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
    setApps((prev) => prev.map((a) => (a._id === id ? { ...a, status: status as DistributorApplication["status"] } : a)));
  }

  return (
    <div>
      <PageHeader title="Distributor Applications" description="People who applied to distribute Tejswaad Masala." />

      <AdminCard className="overflow-x-auto">
        {loading ? (
          <p className="p-6 text-sm text-charcoal/50">Loading...</p>
        ) : apps.length === 0 ? (
          <p className="p-6 text-sm text-charcoal/50">No applications yet.</p>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-charcoal/50 border-b border-gold/10">
                <th className="py-3 px-4">Name</th>
                <th className="py-3 px-4">Location</th>
                <th className="py-3 px-4">Experience</th>
                <th className="py-3 px-4">Investment</th>
                <th className="py-3 px-4">Status</th>
              </tr>
            </thead>
            <tbody>
              {apps.map((a) => (
                <tr key={a._id} className="border-b border-gold/5">
                  <td className="py-3 px-4">
                    <p className="font-medium">{a.fullName}</p>
                    <p className="text-xs text-charcoal/50">{a.phone}</p>
                  </td>
                  <td className="py-3 px-4">{a.city}, {a.state}</td>
                  <td className="py-3 px-4 max-w-[180px] truncate">{a.experience}</td>
                  <td className="py-3 px-4">{a.investmentCapacity}</td>
                  <td className="py-3 px-4">
                    <select
                      value={a.status}
                      onChange={(e) => updateStatus(a._id, e.target.value)}
                      className="text-xs border border-gold/30 rounded-md px-2 py-1"
                    >
                      {STATUSES.map((s) => (
                        <option key={s} value={s}>{s}</option>
                      ))}
                    </select>
                    <div className="mt-1"><StatusBadge status={a.status} /></div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </AdminCard>
    </div>
  );
}
