"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { Plus, Pencil, Trash2, X, Loader2, UploadCloud } from "lucide-react";
import { PageHeader, AdminCard } from "@/components/admin/AdminUI";
import Button from "@/components/ui/Button";
import { Product, WeightOption } from "@/types";
import { categories } from "@/lib/data/products";
import { formatINR, slugify } from "@/lib/utils";

const emptyProduct = {
  name: "",
  category: "Haldi Powder",
  shortDescription: "",
  description: "",
  images: [""],
  weightOptions: [{ weight: "100g", price: 0, mrp: 0, stock: 100 }] as WeightOption[],
  isBestSeller: false,
  isNew: false,
  isActive: true,
};

export default function AdminProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<Partial<Product> | null>(null);
  const [uploading, setUploading] = useState(false);

  async function load() {
    setLoading(true);
    const res = await fetch("/api/products");
    const data = await res.json();
    setProducts(Array.isArray(data) ? data : []);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  async function handleSave() {
    if (!editing) return;
    const payload = { ...editing, slug: editing.slug || slugify(editing.name || "") };
    const method = editing._id ? "PUT" : "POST";
    const url = editing._id ? `/api/products/${editing._id}` : "/api/products";
    await fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    setEditing(null);
    load();
  }

  async function handleDelete(id: string) {
    if (!confirm("Delete this product? This cannot be undone.")) return;
    await fetch(`/api/products/${id}`, { method: "DELETE" });
    load();
  }

  async function handleImageUpload(file: File) {
    setUploading(true);
    const reader = new FileReader();
    reader.onload = async () => {
      const res = await fetch("/api/upload", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ base64: reader.result, folder: "tejswaad/products" }),
      });
      const data = await res.json();
      if (data.url) {
        setEditing((e) => (e ? { ...e, images: [data.url, ...(e.images?.slice(1) ?? [])] } : e));
      }
      setUploading(false);
    };
    reader.readAsDataURL(file);
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <PageHeader title="Products" description="Add, edit or remove spice products and pricing." />
        <Button onClick={() => setEditing({ ...emptyProduct })}>
          <Plus className="w-4 h-4" /> Add Product
        </Button>
      </div>

      <AdminCard className="overflow-x-auto">
        {loading ? (
          <p className="p-6 text-sm text-charcoal/50">Loading products...</p>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-charcoal/50 border-b border-gold/10">
                <th className="py-3 px-4">Product</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Price (from)</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {products.map((p) => (
                <tr key={p._id} className="border-b border-gold/5">
                  <td className="py-3 px-4 flex items-center gap-3">
                    <div className="relative w-10 h-10 rounded-lg overflow-hidden bg-cream-dark shrink-0">
                      {p.images[0] && <Image src={p.images[0]} alt={p.name} fill className="object-cover" />}
                    </div>
                    <span className="font-medium">{p.name}</span>
                  </td>
                  <td className="py-3 px-4 text-charcoal/70">{p.category}</td>
                  <td className="py-3 px-4">{formatINR(p.weightOptions[0]?.price ?? 0)}</td>
                  <td className="py-3 px-4">
                    <span className={p.isActive ? "text-green-600" : "text-red-500"}>
                      {p.isActive ? "Active" : "Hidden"}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <button onClick={() => setEditing(p)} className="p-1.5 text-maroon hover:bg-maroon/10 rounded-md mr-1">
                      <Pencil className="w-4 h-4" />
                    </button>
                    <button onClick={() => handleDelete(p._id)} className="p-1.5 text-chili hover:bg-chili/10 rounded-md">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </AdminCard>

      {editing && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display text-xl text-maroon">
                {editing._id ? "Edit Product" : "Add Product"}
              </h3>
              <button onClick={() => setEditing(null)}>
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div className="grid sm:grid-cols-2 gap-4">
                <Field label="Product Name">
                  <input
                    value={editing.name ?? ""}
                    onChange={(e) => setEditing({ ...editing, name: e.target.value })}
                    className={inputClass}
                  />
                </Field>
                <Field label="Category">
                  <select
                    value={editing.category ?? "Haldi Powder"}
                    onChange={(e) => setEditing({ ...editing, category: e.target.value as Product["category"] })}
                    className={inputClass}
                  >
                    {categories.filter((c) => c !== "All").map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </Field>
              </div>

              <Field label="Short Description">
                <input
                  value={editing.shortDescription ?? ""}
                  onChange={(e) => setEditing({ ...editing, shortDescription: e.target.value })}
                  className={inputClass}
                />
              </Field>

              <Field label="Full Description">
                <textarea
                  rows={3}
                  value={editing.description ?? ""}
                  onChange={(e) => setEditing({ ...editing, description: e.target.value })}
                  className={inputClass}
                />
              </Field>

              <Field label="Product Image">
                <div className="flex items-center gap-3">
                  {editing.images?.[0] && (
                    <div className="relative w-14 h-14 rounded-lg overflow-hidden bg-cream-dark shrink-0">
                      <Image src={editing.images[0]} alt="" fill className="object-cover" />
                    </div>
                  )}
                  <label className="flex items-center gap-2 px-4 py-2 rounded-lg border border-gold/30 cursor-pointer text-sm hover:bg-cream-dark/40">
                    {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <UploadCloud className="w-4 h-4" />}
                    Upload Image
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => e.target.files?.[0] && handleImageUpload(e.target.files[0])}
                    />
                  </label>
                </div>
                <p className="text-xs text-charcoal/40 mt-1">Requires Cloudinary env vars configured on the server.</p>
              </Field>

              <div>
                <label className="block text-xs font-semibold text-charcoal/70 mb-2">Weight & Pricing</label>
                <div className="space-y-2">
                  {(editing.weightOptions ?? []).map((w, i) => (
                    <div key={i} className="grid grid-cols-4 gap-2">
                      <input
                        placeholder="Weight"
                        value={w.weight}
                        onChange={(e) => {
                          const opts = [...(editing.weightOptions ?? [])];
                          opts[i] = { ...opts[i], weight: e.target.value };
                          setEditing({ ...editing, weightOptions: opts });
                        }}
                        className={inputClass}
                      />
                      <input
                        type="number"
                        placeholder="Price"
                        value={w.price}
                        onChange={(e) => {
                          const opts = [...(editing.weightOptions ?? [])];
                          opts[i] = { ...opts[i], price: Number(e.target.value) };
                          setEditing({ ...editing, weightOptions: opts });
                        }}
                        className={inputClass}
                      />
                      <input
                        type="number"
                        placeholder="MRP"
                        value={w.mrp ?? 0}
                        onChange={(e) => {
                          const opts = [...(editing.weightOptions ?? [])];
                          opts[i] = { ...opts[i], mrp: Number(e.target.value) };
                          setEditing({ ...editing, weightOptions: opts });
                        }}
                        className={inputClass}
                      />
                      <button
                        type="button"
                        onClick={() => {
                          const opts = (editing.weightOptions ?? []).filter((_, idx) => idx !== i);
                          setEditing({ ...editing, weightOptions: opts });
                        }}
                        className="text-chili"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                  <button
                    type="button"
                    onClick={() =>
                      setEditing({
                        ...editing,
                        weightOptions: [
                          ...(editing.weightOptions ?? []),
                          { weight: "", price: 0, mrp: 0, stock: 100 },
                        ],
                      })
                    }
                    className="text-sm text-maroon font-medium"
                  >
                    + Add weight option
                  </button>
                </div>
              </div>

              <div className="flex gap-6">
                <label className="flex items-center gap-2 text-sm">
                  <input
                    type="checkbox"
                    checked={!!editing.isBestSeller}
                    onChange={(e) => setEditing({ ...editing, isBestSeller: e.target.checked })}
                  />
                  Best Seller
                </label>
                <label className="flex items-center gap-2 text-sm">
                  <input
                    type="checkbox"
                    checked={!!editing.isActive}
                    onChange={(e) => setEditing({ ...editing, isActive: e.target.checked })}
                  />
                  Active (visible on site)
                </label>
              </div>

              <div className="flex gap-3 pt-2">
                <Button onClick={handleSave} className="flex-1">
                  Save Product
                </Button>
                <Button variant="outline" onClick={() => setEditing(null)}>
                  Cancel
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

const inputClass =
  "w-full px-3 py-2 rounded-lg border border-gold/30 focus:outline-none focus:ring-2 focus:ring-gold text-sm";

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-xs font-semibold text-charcoal/70 mb-1.5">{label}</label>
      {children}
    </div>
  );
}
