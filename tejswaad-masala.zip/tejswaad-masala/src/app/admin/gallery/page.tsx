"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { Trash2, UploadCloud, Loader2 } from "lucide-react";
import { PageHeader, AdminCard } from "@/components/admin/AdminUI";
import { GalleryImage } from "@/types";

const CATEGORIES = ["Spices", "Factory", "Packaging", "Team"];

export default function AdminGalleryPage() {
  const [images, setImages] = useState<GalleryImage[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [category, setCategory] = useState("Spices");
  const [caption, setCaption] = useState("");

  async function load() {
    setLoading(true);
    const res = await fetch("/api/gallery");
    const data = await res.json();
    setImages(Array.isArray(data) ? data : []);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  async function handleUpload(file: File) {
    setUploading(true);
    const reader = new FileReader();
    reader.onload = async () => {
      const uploadRes = await fetch("/api/upload", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ base64: reader.result, folder: "tejswaad/gallery" }),
      });
      const { url } = await uploadRes.json();
      if (url) {
        await fetch("/api/gallery", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ url, category, caption }),
        });
        setCaption("");
        load();
      }
      setUploading(false);
    };
    reader.readAsDataURL(file);
  }

  async function remove(id: string) {
    if (!confirm("Delete this image?")) return;
    await fetch(`/api/gallery/${id}`, { method: "DELETE" });
    setImages((prev) => prev.filter((i) => i._id !== id));
  }

  return (
    <div>
      <PageHeader title="Gallery" description="Manage the images shown on the public Gallery page." />

      <AdminCard className="p-5 mb-6">
        <div className="grid sm:grid-cols-3 gap-3">
          <select value={category} onChange={(e) => setCategory(e.target.value)} className="px-3 py-2 rounded-lg border border-gold/30 text-sm">
            {CATEGORIES.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
          <input
            placeholder="Caption (optional)"
            value={caption}
            onChange={(e) => setCaption(e.target.value)}
            className="px-3 py-2 rounded-lg border border-gold/30 text-sm sm:col-span-2"
          />
        </div>
        <label className="mt-3 flex items-center justify-center gap-2 px-4 py-3 rounded-lg border-2 border-dashed border-gold/40 cursor-pointer text-sm hover:bg-cream-dark/30">
          {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <UploadCloud className="w-4 h-4" />}
          Click to upload an image
          <input
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => e.target.files?.[0] && handleUpload(e.target.files[0])}
          />
        </label>
      </AdminCard>

      {loading ? (
        <p className="text-sm text-charcoal/50">Loading...</p>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
          {images.map((img) => (
            <div key={img._id} className="relative rounded-xl overflow-hidden aspect-square group">
              <Image src={img.url} alt={img.caption ?? ""} fill className="object-cover" />
              <button
                onClick={() => remove(img._id)}
                className="absolute top-2 right-2 w-7 h-7 rounded-full bg-black/50 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
              <span className="absolute bottom-1 left-1 text-[10px] bg-black/50 text-white px-1.5 py-0.5 rounded">
                {img.category}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
