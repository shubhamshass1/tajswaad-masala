import type { Metadata } from "next";
import { Playfair_Display, Poppins, Cormorant_Garamond } from "next/font/google";
import "./globals.css";
import { CartProvider } from "@/context/CartContext";
import { WishlistProvider } from "@/context/WishlistContext";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import WhatsAppButton from "@/components/layout/WhatsAppButton";
import CallButton from "@/components/layout/CallButton";
import ScrollToTop from "@/components/layout/ScrollToTop";
import LoadingScreen from "@/components/LoadingScreen";
import AIChatAssistant from "@/components/AIChatAssistant";
import { BUSINESS } from "@/lib/utils";

const playfair = Playfair_Display({
  subsets: ["latin"],
  variable: "--font-playfair",
  weight: ["500", "600", "700", "800"],
});
const poppins = Poppins({
  subsets: ["latin"],
  variable: "--font-poppins",
  weight: ["300", "400", "500", "600", "700"],
});
const cormorant = Cormorant_Garamond({
  subsets: ["latin"],
  variable: "--font-cormorant",
  style: ["italic", "normal"],
  weight: ["500", "600"],
});

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? "https://www.tejswaadmasala.com";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "Tejswaad Masala – Ghar Jaisa Taste | Pure & Fresh Indian Spices",
    template: "%s | Tejswaad Masala",
  },
  description:
    "Tejswaad Masala is a manufacturer and supplier of pure, fresh Indian spices from Begusarai, Bihar — Haldi, Mirchi, Garam Masala, Chicken Masala and more. FSSAI certified. Ghar jaisa taste, delivered.",
  keywords: [
    "Tejswaad Masala",
    "spices Bihar",
    "Haldi powder",
    "Garam Masala",
    "Chicken Masala",
    "spice manufacturer Begusarai",
    "bulk spice supplier India",
  ],
  authors: [{ name: "Tejswaad Masala" }],
  openGraph: {
    title: "Tejswaad Masala – Ghar Jaisa Taste",
    description: "Pure, Fresh and Authentic Indian Spices, manufactured in Begusarai, Bihar.",
    url: siteUrl,
    siteName: "Tejswaad Masala",
    images: ["/images/logo.png"],
    locale: "en_IN",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Tejswaad Masala – Ghar Jaisa Taste",
    description: "Pure, Fresh and Authentic Indian Spices.",
    images: ["/images/logo.png"],
  },
  manifest: "/manifest.json",
  icons: {
    icon: "/images/icon-192.png",
    apple: "/images/icon-192.png",
  },
};

const schemaMarkup = {
  "@context": "https://schema.org",
  "@type": "Organization",
  name: BUSINESS.name,
  description: BUSINESS.type,
  url: siteUrl,
  logo: `${siteUrl}/images/logo.png`,
  telephone: BUSINESS.phonePrimary,
  email: BUSINESS.email,
  address: {
    "@type": "PostalAddress",
    streetAddress: "Ward 13, Kiul, Garhara, Teghra",
    addressLocality: "Begusarai",
    addressRegion: "Bihar",
    postalCode: "851126",
    addressCountry: "IN",
  },
  sameAs: [BUSINESS.instagram],
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${playfair.variable} ${poppins.variable} ${cormorant.variable}`}>
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(schemaMarkup) }}
        />
        {process.env.NEXT_PUBLIC_GA_ID && (
          <>
            <script
              async
              src={`https://www.googletagmanager.com/gtag/js?id=${process.env.NEXT_PUBLIC_GA_ID}`}
            />
            <script
              dangerouslySetInnerHTML={{
                __html: `window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','${process.env.NEXT_PUBLIC_GA_ID}');`,
              }}
            />
          </>
        )}
      </head>
      <body>
        <LoadingScreen />
        <CartProvider>
          <WishlistProvider>
            <Navbar />
            <main>{children}</main>
            <Footer />
            <WhatsAppButton />
            <CallButton />
            <ScrollToTop />
            <AIChatAssistant />
          </WishlistProvider>
        </CartProvider>
      </body>
    </html>
  );
}
