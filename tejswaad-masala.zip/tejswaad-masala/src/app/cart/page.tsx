"use client";

import Image from "next/image";
import Link from "next/link";
import { Minus, Plus, Trash2, ShoppingBag, ArrowRight } from "lucide-react";
import Button from "@/components/ui/Button";
import { useCart } from "@/context/CartContext";
import { formatINR } from "@/lib/utils";

export default function CartPage() {
  const { items, removeItem, updateQuantity, subtotal } = useCart();

  if (items.length === 0) {
    return (
      <div className="pt-32 pb-20 min-h-[60vh] flex flex-col items-center justify-center text-center px-6">
        <ShoppingBag className="w-16 h-16 text-maroon/30 dark:text-gold/30 mb-4" />
        <h1 className="font-display text-2xl text-charcoal dark:text-cream mb-2">
          Your cart is empty
        </h1>
        <p className="text-charcoal/60 dark:text-cream/60 mb-6">
          Browse our spice collection and add something delicious.
        </p>
        <Link href="/products">
          <Button size="lg">Explore Products</Button>
        </Link>
      </div>
    );
  }

  const shipping = subtotal >= 499 ? 0 : 49;

  return (
    <div className="pt-28 pb-20 bg-cream dark:bg-charcoal min-h-screen">
      <div className="mx-auto max-w-5xl px-6 md:px-8">
        <h1 className="font-display text-3xl text-maroon dark:text-cream mb-8">Your Cart</h1>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-4">
            {items.map((item) => (
              <div
                key={`${item.productId}-${item.weight}`}
                className="flex gap-4 p-4 rounded-2xl bg-white/70 dark:bg-white/5 border border-gold/20"
              >
                <div className="relative w-20 h-20 rounded-xl overflow-hidden shrink-0 bg-cream-dark">
                  <Image src={item.image} alt={item.name} fill className="object-cover" />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-display text-charcoal dark:text-cream truncate">{item.name}</h3>
                  <p className="text-xs text-charcoal/50 dark:text-cream/50 mb-2">{item.weight}</p>
                  <div className="flex items-center gap-3">
                    <div className="flex items-center border border-gold/30 rounded-full">
                      <button
                        onClick={() => updateQuantity(item.productId, item.weight, item.quantity - 1)}
                        className="p-1.5"
                        aria-label="Decrease quantity"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="w-6 text-center text-sm">{item.quantity}</span>
                      <button
                        onClick={() => updateQuantity(item.productId, item.weight, item.quantity + 1)}
                        className="p-1.5"
                        aria-label="Increase quantity"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <button
                      onClick={() => removeItem(item.productId, item.weight)}
                      className="text-chili/70 hover:text-chili"
                      aria-label="Remove item"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-display text-maroon dark:text-gold-light">
                    {formatINR(item.price * item.quantity)}
                  </p>
                </div>
              </div>
            ))}
          </div>

          <div className="p-6 rounded-2xl bg-white/70 dark:bg-white/5 border border-gold/20 h-fit sticky top-28">
            <h3 className="font-display text-lg text-charcoal dark:text-cream mb-4">Order Summary</h3>
            <div className="space-y-2 text-sm text-charcoal/70 dark:text-cream/70">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span>{formatINR(subtotal)}</span>
              </div>
              <div className="flex justify-between">
                <span>Shipping</span>
                <span>{shipping === 0 ? "Free" : formatINR(shipping)}</span>
              </div>
              {shipping > 0 && (
                <p className="text-xs text-forest dark:text-gold-light">
                  Add {formatINR(499 - subtotal)} more for free shipping
                </p>
              )}
            </div>
            <div className="flex justify-between font-display text-lg text-maroon dark:text-gold-light mt-4 pt-4 border-t border-gold/20">
              <span>Total</span>
              <span>{formatINR(subtotal + shipping)}</span>
            </div>
            <Link href="/checkout">
              <Button size="lg" className="w-full mt-6">
                Proceed to Checkout <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
