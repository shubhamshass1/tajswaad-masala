import type { Metadata } from "next";
import { Phone, Mail, MapPin, MessageCircle, Clock } from "lucide-react";
import SectionHeading from "@/components/ui/SectionHeading";
import RevealOnScroll from "@/components/ui/RevealOnScroll";
import ContactForm from "@/components/forms/ContactForm";
import { BUSINESS, whatsappLink } from "@/lib/utils";

export const metadata: Metadata = {
  title: "Contact Us",
  description:
    "Get in touch with Tejswaad Masala — Ward 13, Kiul, Garhara, Teghra, Begusarai, Bihar. Call, WhatsApp or email us.",
};

export default function ContactPage() {
  return (
    <div className="pt-24 pb-20 bg-cream dark:bg-charcoal min-h-screen">
      <section className="py-12 md:py-16">
        <div className="mx-auto max-w-4xl px-6 text-center">
          <SectionHeading
            eyebrow="Get In Touch"
            title="We'd Love to Hear From You"
            description="Questions about our products, bulk orders or distribution? Reach out any way that suits you."
          />
        </div>
      </section>

      <section className="pb-20">
        <div className="mx-auto max-w-6xl px-6 md:px-8 grid lg:grid-cols-5 gap-10">
          <RevealOnScroll className="lg:col-span-2">
            <div className="space-y-4">
              <InfoCard icon={Phone} title="Call Us">
                <a href={`tel:${BUSINESS.phonePrimary}`} className="block hover:text-maroon dark:hover:text-gold-light">
                  {BUSINESS.phonePrimary}
                </a>
                <a href={`tel:${BUSINESS.phoneSecondary}`} className="block hover:text-maroon dark:hover:text-gold-light">
                  {BUSINESS.phoneSecondary}
                </a>
              </InfoCard>
              <InfoCard icon={MessageCircle} title="WhatsApp">
                <a
                  href={whatsappLink("Hi Tejswaad Masala, I have a question.")}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-maroon dark:hover:text-gold-light"
                >
                  Chat with us instantly
                </a>
              </InfoCard>
              <InfoCard icon={Mail} title="Email">
                <a href={`mailto:${BUSINESS.email}`} className="hover:text-maroon dark:hover:text-gold-light break-all">
                  {BUSINESS.email}
                </a>
              </InfoCard>
              <InfoCard icon={MapPin} title="Address">
                {BUSINESS.address}
              </InfoCard>
              <InfoCard icon={Clock} title="Business Hours">
                Monday – Saturday: 9:00 AM – 7:00 PM
                <br />
                Sunday: 10:00 AM – 2:00 PM
              </InfoCard>
            </div>
          </RevealOnScroll>

          <RevealOnScroll delay={0.15} className="lg:col-span-3 space-y-8">
            <ContactForm />
            <div className="rounded-2xl overflow-hidden shadow-glass border border-gold/20 h-72">
              <iframe
                title="Tejswaad Masala Location"
                src="https://www.google.com/maps?q=Kiul,Garhara,Teghra,Begusarai,Bihar,851126&output=embed"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </RevealOnScroll>
        </div>
      </section>
    </div>
  );
}

function InfoCard({
  icon: Icon,
  title,
  children,
}: {
  icon: typeof Phone;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className="p-5 rounded-2xl bg-white/70 dark:bg-white/5 border border-gold/20 flex gap-4">
      <div className="w-10 h-10 rounded-full bg-maroon/10 dark:bg-gold/10 flex items-center justify-center shrink-0">
        <Icon className="w-5 h-5 text-maroon dark:text-gold-light" />
      </div>
      <div>
        <h4 className="font-display text-sm text-charcoal dark:text-cream mb-1">{title}</h4>
        <div className="text-sm text-charcoal/70 dark:text-cream/70 leading-relaxed">{children}</div>
      </div>
    </div>
  );
}
