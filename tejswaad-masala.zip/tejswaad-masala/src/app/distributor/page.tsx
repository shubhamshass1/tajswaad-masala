import type { Metadata } from "next";
import { TrendingUp, HandCoins, Package, Headphones } from "lucide-react";
import SectionHeading from "@/components/ui/SectionHeading";
import RevealOnScroll from "@/components/ui/RevealOnScroll";
import DistributorForm from "@/components/forms/DistributorForm";

export const metadata: Metadata = {
  title: "Become a Distributor",
  description:
    "Partner with Tejswaad Masala as a regional distributor. Attractive margins, marketing support and reliable supply of pure spices.",
};

const BENEFITS = [
  { icon: TrendingUp, title: "Growing Demand", text: "Ride the demand for pure, chemical-free spices in your region." },
  { icon: HandCoins, title: "Attractive Margins", text: "Competitive distributor pricing with healthy profit margins." },
  { icon: Package, title: "Reliable Supply", text: "Consistent stock availability with organised dispatch." },
  { icon: Headphones, title: "Dedicated Support", text: "Direct line to the Tejswaad team for orders and queries." },
];

export default function DistributorPage() {
  return (
    <div className="pt-24 pb-20 bg-cream dark:bg-charcoal min-h-screen">
      <section className="py-12 md:py-16">
        <div className="mx-auto max-w-4xl px-6 text-center">
          <SectionHeading
            eyebrow="Partner With Us"
            title="Become a Tejswaad Masala Distributor"
            description="Join our growing distribution network and bring ghar jaisa taste to more homes across your region."
          />
        </div>
      </section>

      <section className="pb-16">
        <div className="mx-auto max-w-6xl px-6 md:px-8 grid grid-cols-2 md:grid-cols-4 gap-4">
          {BENEFITS.map((b) => (
            <RevealOnScroll key={b.title}>
              <div className="p-5 rounded-2xl bg-white/70 dark:bg-white/5 border border-gold/20 h-full text-center">
                <b.icon className="w-7 h-7 text-forest dark:text-gold-light mx-auto mb-3" />
                <h4 className="font-display text-sm text-charcoal dark:text-cream mb-1">{b.title}</h4>
                <p className="text-xs text-charcoal/60 dark:text-cream/60">{b.text}</p>
              </div>
            </RevealOnScroll>
          ))}
        </div>
      </section>

      <section>
        <div className="mx-auto max-w-4xl px-6 md:px-8">
          <RevealOnScroll>
            <DistributorForm />
          </RevealOnScroll>
        </div>
      </section>
    </div>
  );
}
