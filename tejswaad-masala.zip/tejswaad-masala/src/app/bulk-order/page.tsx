import type { Metadata } from "next";
import { Store, Building2, UtensilsCrossed, Truck } from "lucide-react";
import SectionHeading from "@/components/ui/SectionHeading";
import RevealOnScroll from "@/components/ui/RevealOnScroll";
import BulkOrderForm from "@/components/forms/BulkOrderForm";

export const metadata: Metadata = {
  title: "Bulk Order",
  description:
    "Bulk spice supply for retailers, wholesalers, restaurants and distributors. Request a quotation from Tejswaad Masala, Begusarai, Bihar.",
};

const AUDIENCE = [
  { icon: Store, title: "Retailers", text: "Stock pure spices your customers trust and repeat-buy." },
  { icon: Building2, title: "Wholesalers", text: "Competitive bulk pricing with reliable, consistent supply." },
  { icon: UtensilsCrossed, title: "Restaurants", text: "Restaurant-grade masalas for consistent kitchen results." },
  { icon: Truck, title: "Distributors", text: "Partner with us to grow Tejswaad Masala in your region." },
];

export default function BulkOrderPage() {
  return (
    <div className="pt-24 pb-20 bg-cream dark:bg-charcoal min-h-screen">
      <section className="py-12 md:py-16">
        <div className="mx-auto max-w-4xl px-6 text-center">
          <SectionHeading
            eyebrow="For Businesses"
            title="Bulk Spice Orders for Retailers & Restaurants"
            description="Reliable supply, fair pricing and consistent quality — built for businesses that can't afford inconsistency."
          />
        </div>
      </section>

      <section className="pb-16">
        <div className="mx-auto max-w-6xl px-6 md:px-8 grid grid-cols-2 md:grid-cols-4 gap-4">
          {AUDIENCE.map((a) => (
            <RevealOnScroll key={a.title}>
              <div className="p-5 rounded-2xl bg-white/70 dark:bg-white/5 border border-gold/20 h-full text-center">
                <a.icon className="w-7 h-7 text-maroon dark:text-gold-light mx-auto mb-3" />
                <h4 className="font-display text-sm text-charcoal dark:text-cream mb-1">{a.title}</h4>
                <p className="text-xs text-charcoal/60 dark:text-cream/60">{a.text}</p>
              </div>
            </RevealOnScroll>
          ))}
        </div>
      </section>

      <section className="pb-8">
        <div className="mx-auto max-w-4xl px-6 md:px-8">
          <RevealOnScroll>
            <BulkOrderForm />
          </RevealOnScroll>
        </div>
      </section>

      <section>
        <div className="mx-auto max-w-4xl px-6 md:px-8 text-center text-sm text-charcoal/60 dark:text-cream/60">
          <p>
            Minimum Order Quantity (MOQ): 10kg per product category. Custom packaging and private
            labelling available for large orders — mention this in your message above.
          </p>
        </div>
      </section>
    </div>
  );
}
