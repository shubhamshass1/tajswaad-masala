import { Suspense } from "react";
import Link from "next/link";
import { CheckCircle2 } from "lucide-react";
import Button from "@/components/ui/Button";

function SuccessContent({ order }: { order?: string }) {
  return (
    <div className="pt-32 pb-20 min-h-[70vh] flex flex-col items-center justify-center text-center px-6">
      <CheckCircle2 className="w-20 h-20 text-forest mb-6" />
      <h1 className="font-display text-3xl text-maroon dark:text-cream mb-2">
        Order Placed Successfully!
      </h1>
      {order && (
        <p className="text-charcoal/70 dark:text-cream/70 mb-1">
          Your order number is <span className="font-semibold">{order}</span>
        </p>
      )}
      <p className="text-charcoal/60 dark:text-cream/60 max-w-md mb-8">
        Thank you for choosing Tejswaad Masala. We'll begin processing your order right away and
        notify you once it ships.
      </p>
      <div className="flex gap-4">
        <Link href="/products">
          <Button size="lg">Continue Shopping</Button>
        </Link>
        <Link href="/contact">
          <Button size="lg" variant="outline">
            Need Help?
          </Button>
        </Link>
      </div>
    </div>
  );
}

export default async function OrderSuccessPage({
  searchParams,
}: {
  searchParams: Promise<{ order?: string }>;
}) {
  const params = await searchParams;
  return (
    <Suspense>
      <SuccessContent order={params.order} />
    </Suspense>
  );
}
