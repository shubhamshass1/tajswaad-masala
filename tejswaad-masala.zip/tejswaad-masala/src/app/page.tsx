import HeroSection from "@/components/home/HeroSection";
import AboutPreview from "@/components/home/AboutPreview";
import CategoryShowcase from "@/components/home/CategoryShowcase";
import BestSellers from "@/components/home/BestSellers";
import WhyUs from "@/components/home/WhyUs";
import TestimonialSlider from "@/components/home/TestimonialSlider";
import CTASection from "@/components/home/CTASection";
import Newsletter from "@/components/home/Newsletter";

export default function HomePage() {
  return (
    <>
      <HeroSection />
      <AboutPreview />
      <CategoryShowcase />
      <BestSellers />
      <WhyUs />
      <TestimonialSlider />
      <CTASection />
      <Newsletter />
    </>
  );
}
