import type { Metadata } from "next";
import SectionHeading from "@/components/ui/SectionHeading";
import GalleryGrid from "@/components/products/GalleryGrid";
import { galleryImages } from "@/lib/data/testimonials";

export const metadata: Metadata = {
  title: "Gallery",
  description: "A glimpse into Tejswaad Masala's spices, factory and packaging process.",
};

export default function GalleryPage() {
  return (
    <div className="pt-24 pb-20 bg-cream dark:bg-charcoal min-h-screen">
      <section className="py-12 md:py-16">
        <div className="mx-auto max-w-4xl px-6 text-center">
          <SectionHeading
            eyebrow="Behind the Scenes"
            title="Our Spices, Our Process"
            description="From raw spice to the packet in your kitchen — a look inside Tejswaad Masala."
          />
        </div>
      </section>
      <section className="pb-8">
        <div className="mx-auto max-w-7xl px-6 md:px-8">
          <GalleryGrid images={galleryImages} />
        </div>
      </section>
    </div>
  );
}
