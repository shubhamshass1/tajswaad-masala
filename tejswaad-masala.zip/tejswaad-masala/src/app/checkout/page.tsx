import { Suspense } from "react";
import type { Metadata } from "next";
import CheckoutClient from "@/components/products/CheckoutClient";

export const metadata: Metadata = {
  title: "Checkout",
};

export default function CheckoutPage() {
  return (
    <Suspense fallback={<div className="pt-32 text-center">Loading checkout...</div>}>
      <CheckoutClient />
    </Suspense>
  );
}
