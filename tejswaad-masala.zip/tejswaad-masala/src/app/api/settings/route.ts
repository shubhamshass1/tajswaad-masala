import { NextRequest, NextResponse } from "next/server";
import { connectDB } from "@/lib/mongodb";
import SiteSettings from "@/lib/models/SiteSettings";
import { requireAdmin } from "@/lib/apiAuth";

export async function GET() {
  await connectDB();
  let settings = await SiteSettings.findOne({ key: "main" });
  if (!settings) settings = await SiteSettings.create({ key: "main" });
  return NextResponse.json(settings);
}

export async function PUT(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  await connectDB();
  const body = await req.json();
  const settings = await SiteSettings.findOneAndUpdate({ key: "main" }, body, {
    new: true,
    upsert: true,
  });
  return NextResponse.json(settings);
}
