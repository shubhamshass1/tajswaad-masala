import { NextRequest, NextResponse } from "next/server";
import crypto from "crypto";

// Verifies the signature Razorpay sends back after a successful checkout,
// confirming the payment wasn't tampered with client-side.
export async function POST(req: NextRequest) {
  const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = await req.json();

  const expectedSignature = crypto
    .createHmac("sha256", process.env.RAZORPAY_KEY_SECRET as string)
    .update(`${razorpay_order_id}|${razorpay_payment_id}`)
    .digest("hex");

  const isValid = expectedSignature === razorpay_signature;

  if (!isValid) {
    return NextResponse.json({ verified: false }, { status: 400 });
  }
  return NextResponse.json({ verified: true });
}
