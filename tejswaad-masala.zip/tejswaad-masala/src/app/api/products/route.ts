import { NextRequest, NextResponse } from "next/server";
import { connectDB } from "@/lib/mongodb";
import Product from "@/lib/models/Product";
import { requireAdmin } from "@/lib/apiAuth";
import { slugify } from "@/lib/utils";

export async function GET(req: NextRequest) {
  await connectDB();
  const category = req.nextUrl.searchParams.get("category");
  const query: Record<string, unknown> = { isActive: true };
  if (category && category !== "All") query.category = category;
  const products = await Product.find(query).sort({ createdAt: -1 });
  return NextResponse.json(products);
}

export async function POST(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  await connectDB();
  const body = await req.json();
  const slug = body.slug || slugify(body.name);
  const product = await Product.create({ ...body, slug });
  return NextResponse.json(product, { status: 201 });
}
