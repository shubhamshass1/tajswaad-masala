import { NextRequest, NextResponse } from "next/server";
import { connectDB } from "@/lib/mongodb";
import GalleryImage from "@/lib/models/GalleryImage";
import { requireAdmin } from "@/lib/apiAuth";

export async function GET() {
  await connectDB();
  const images = await GalleryImage.find().sort({ createdAt: -1 });
  return NextResponse.json(images);
}

export async function POST(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  await connectDB();
  const body = await req.json();
  const image = await GalleryImage.create(body);
  return NextResponse.json(image, { status: 201 });
}
