import { NextRequest, NextResponse } from "next/server";
import { connectDB } from "@/lib/mongodb";
import Testimonial from "@/lib/models/Testimonial";
import { requireAdmin } from "@/lib/apiAuth";

export async function GET(req: NextRequest) {
  await connectDB();
  const all = req.nextUrl.searchParams.get("all");

  if (all === "true") {
    const session = await requireAdmin();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    const testimonials = await Testimonial.find().sort({ createdAt: -1 });
    return NextResponse.json(testimonials);
  }

  const testimonials = await Testimonial.find({ isApproved: true }).sort({ createdAt: -1 });
  return NextResponse.json(testimonials);
}

export async function POST(req: NextRequest) {
  await connectDB();
  const body = await req.json();
  const testimonial = await Testimonial.create({ ...body, isApproved: false });
  return NextResponse.json(testimonial, { status: 201 });
}
