import { NextRequest, NextResponse } from "next/server";
import { connectDB } from "@/lib/mongodb";
import Distributor from "@/lib/models/Distributor";
import { requireAdmin } from "@/lib/apiAuth";

export async function GET() {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  await connectDB();
  const applications = await Distributor.find().sort({ createdAt: -1 });
  return NextResponse.json(applications);
}

export async function POST(req: NextRequest) {
  await connectDB();
  const body = await req.json();
  const application = await Distributor.create(body);
  return NextResponse.json(application, { status: 201 });
}
