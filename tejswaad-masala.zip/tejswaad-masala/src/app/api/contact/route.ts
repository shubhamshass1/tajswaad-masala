import { NextRequest, NextResponse } from "next/server";
import { connectDB } from "@/lib/mongodb";
import ContactMessage from "@/lib/models/ContactMessage";
import { requireAdmin } from "@/lib/apiAuth";

export async function GET() {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  await connectDB();
  const messages = await ContactMessage.find().sort({ createdAt: -1 });
  return NextResponse.json(messages);
}

export async function POST(req: NextRequest) {
  await connectDB();
  const body = await req.json();
  const message = await ContactMessage.create(body);
  return NextResponse.json(message, { status: 201 });
}
