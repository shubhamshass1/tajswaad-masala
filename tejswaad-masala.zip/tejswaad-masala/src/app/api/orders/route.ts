import { NextRequest, NextResponse } from "next/server";
import { connectDB } from "@/lib/mongodb";
import Order from "@/lib/models/Order";
import { requireAdmin } from "@/lib/apiAuth";
import { generateOrderNumber } from "@/lib/utils";
import { sendOrderConfirmationEmail } from "@/lib/sendEmail";

export async function GET(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  await connectDB();
  const status = req.nextUrl.searchParams.get("status");
  const query: Record<string, unknown> = {};
  if (status) query.status = status;
  const orders = await Order.find(query).sort({ createdAt: -1 });
  return NextResponse.json(orders);
}

export async function POST(req: NextRequest) {
  await connectDB();
  const body = await req.json();
  const orderNumber = generateOrderNumber();

  const order = await Order.create({ ...body, orderNumber });

  // Fire-and-forget confirmation email; never block order creation on it.
  if (body.customer?.email) {
    sendOrderConfirmationEmail(body.customer.email, orderNumber, body.total).catch((err) =>
      console.error("Order email failed:", err)
    );
  }

  return NextResponse.json(order, { status: 201 });
}
