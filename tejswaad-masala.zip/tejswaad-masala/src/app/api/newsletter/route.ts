import { NextRequest, NextResponse } from "next/server";
import { connectDB } from "@/lib/mongodb";
import mongoose, { Schema, models, model } from "mongoose";

const NewsletterSchema = new Schema(
  { email: { type: String, required: true, unique: true } },
  { timestamps: true }
);
const Newsletter = models.Newsletter || model("Newsletter", NewsletterSchema);

export async function POST(req: NextRequest) {
  await connectDB();
  const { email } = await req.json();
  if (!email) return NextResponse.json({ error: "Email required" }, { status: 400 });

  try {
    await Newsletter.create({ email });
  } catch (err) {
    // Duplicate email is fine — treat as already subscribed.
    if ((err as { code?: number }).code !== 11000) {
      return NextResponse.json({ error: "Could not subscribe" }, { status: 500 });
    }
  }
  return NextResponse.json({ success: true });
}
