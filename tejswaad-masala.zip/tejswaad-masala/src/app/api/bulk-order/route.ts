import { NextRequest, NextResponse } from "next/server";
import { connectDB } from "@/lib/mongodb";
import BulkOrder from "@/lib/models/BulkOrder";
import { requireAdmin } from "@/lib/apiAuth";

export async function GET() {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  await connectDB();
  const inquiries = await BulkOrder.find().sort({ createdAt: -1 });
  return NextResponse.json(inquiries);
}

export async function POST(req: NextRequest) {
  await connectDB();
  const body = await req.json();
  const inquiry = await BulkOrder.create(body);
  return NextResponse.json(inquiry, { status: 201 });
}
