import { NextRequest, NextResponse } from "next/server";
import { connectDB } from "@/lib/mongodb";
import BulkOrder from "@/lib/models/BulkOrder";
import { requireAdmin } from "@/lib/apiAuth";

type Params = { params: Promise<{ id: string }> };

export async function PUT(req: NextRequest, { params }: Params) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  await connectDB();
  const { id } = await params;
  const body = await req.json();
  const inquiry = await BulkOrder.findByIdAndUpdate(id, body, { new: true });
  if (!inquiry) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json(inquiry);
}

export async function DELETE(_req: NextRequest, { params }: Params) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  await connectDB();
  const { id } = await params;
  await BulkOrder.findByIdAndDelete(id);
  return NextResponse.json({ success: true });
}
