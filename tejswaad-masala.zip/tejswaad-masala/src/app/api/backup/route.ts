import { NextResponse } from "next/server";
import { connectDB } from "@/lib/mongodb";
import { requireAdmin } from "@/lib/apiAuth";
import Product from "@/lib/models/Product";
import Order from "@/lib/models/Order";
import BulkOrder from "@/lib/models/BulkOrder";
import Distributor from "@/lib/models/Distributor";
import Testimonial from "@/lib/models/Testimonial";
import ContactMessage from "@/lib/models/ContactMessage";
import GalleryImage from "@/lib/models/GalleryImage";
import SiteSettings from "@/lib/models/SiteSettings";

// Exports every collection as a single JSON file the owner can download and
// store safely — a simple, dependency-free backup strategy for a small
// business site. For larger scale, use MongoDB Atlas's built-in automated
// backups instead.
export async function GET() {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  await connectDB();
  const [products, orders, bulkOrders, distributors, testimonials, messages, gallery, settings] =
    await Promise.all([
      Product.find(),
      Order.find(),
      BulkOrder.find(),
      Distributor.find(),
      Testimonial.find(),
      ContactMessage.find(),
      GalleryImage.find(),
      SiteSettings.find(),
    ]);

  const backup = {
    exportedAt: new Date().toISOString(),
    products,
    orders,
    bulkOrders,
    distributors,
    testimonials,
    messages,
    gallery,
    settings,
  };

  return new NextResponse(JSON.stringify(backup, null, 2), {
    headers: {
      "Content-Type": "application/json",
      "Content-Disposition": `attachment; filename="tejswaad-backup-${Date.now()}.json"`,
    },
  });
}
