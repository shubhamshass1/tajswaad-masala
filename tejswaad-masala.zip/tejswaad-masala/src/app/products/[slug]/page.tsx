import type { Metadata } from "next";
import Image from "next/image";
import { notFound } from "next/navigation";
import SectionHeading from "@/components/ui/SectionHeading";
import ProductCard from "@/components/products/ProductCard";
import ProductDetailClient from "@/components/products/ProductDetailClient";
import { products } from "@/lib/data/products";

type Props = { params: Promise<{ slug: string }> };

export async function generateStaticParams() {
  return products.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const product = products.find((p) => p.slug === slug);
  if (!product) return {};
  return {
    title: product.name,
    description: product.shortDescription,
    openGraph: { images: [product.images[0]] },
  };
}

export default async function ProductDetailPage({ params }: Props) {
  const { slug } = await params;
  const product = products.find((p) => p.slug === slug);
  if (!product) notFound();

  const related = products.filter((p) => p.category === product.category && p._id !== product._id).slice(0, 4);

  return (
    <div className="pt-28 pb-20 bg-cream dark:bg-charcoal min-h-screen">
      <div className="mx-auto max-w-6xl px-6 md:px-8">
        <div className="grid md:grid-cols-2 gap-12 mb-20">
          <div className="relative aspect-square rounded-3xl overflow-hidden shadow-premium bg-cream-dark/50">
            <Image src={product.images[0]} alt={product.name} fill className="object-cover" priority />
          </div>
          <ProductDetailClient product={product} />
        </div>

        {related.length > 0 && (
          <div>
            <SectionHeading eyebrow="You May Also Like" title="More From This Category" align="left" />
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
              {related.map((p) => (
                <ProductCard key={p._id} product={p} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
