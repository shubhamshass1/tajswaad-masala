import type { Metadata } from "next";
import { Suspense } from "react";
import SectionHeading from "@/components/ui/SectionHeading";
import ProductGrid from "@/components/products/ProductGrid";

export const metadata: Metadata = {
  title: "Our Products",
  description:
    "Browse Tejswaad Masala's full range of pure spices — Haldi, Mirchi, Dhaniya, Garam Masala, Chicken Masala, Kitchen King Masala and more.",
};

export default function ProductsPage() {
  return (
    <div className="pt-28 pb-20 bg-cream dark:bg-charcoal min-h-screen">
      <div className="mx-auto max-w-7xl px-6 md:px-8">
        <SectionHeading
          eyebrow="Shop Tejswaad"
          title="Our Complete Spice Collection"
          description="Pure, fresh and stone-ground — choose your favourite masala and weight."
        />
        <Suspense fallback={<div className="text-center py-20">Loading products...</div>}>
          <ProductGrid />
        </Suspense>
      </div>
    </div>
  );
}
