export { default } from "next-auth/middleware";

export const config = {
  // Protect every /admin route except the login page itself.
  matcher: ["/admin/((?!login).*)"],
};
