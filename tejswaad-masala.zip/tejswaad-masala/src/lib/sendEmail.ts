import nodemailer from "nodemailer";

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: Number(process.env.SMTP_PORT ?? 465),
  secure: true,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

export async function sendOrderConfirmationEmail(to: string, orderNumber: string, total: number) {
  if (!to) return;
  await transporter.sendMail({
    from: process.env.SMTP_FROM,
    to,
    subject: `Tejswaad Masala — Order Confirmed (${orderNumber})`,
    html: `
      <div style="font-family: sans-serif; max-width: 480px; margin: auto;">
        <h2 style="color:#8B0F13;">Thank you for your order!</h2>
        <p>Your order <strong>${orderNumber}</strong> has been received and is being processed.</p>
        <p><strong>Order Total:</strong> ₹${total}</p>
        <p>We'll notify you once it ships. For any questions, reply to this email or call us at +91 6201540120.</p>
        <p style="margin-top:24px;">— Team Tejswaad Masala<br/>Ghar Jaisa Taste</p>
      </div>
    `,
  });
}
