import { Schema, models, model } from "mongoose";

const DistributorSchema = new Schema(
  {
    fullName: { type: String, required: true },
    phone: { type: String, required: true },
    email: String,
    city: { type: String, required: true },
    state: { type: String, required: true },
    experience: { type: String, required: true },
    investmentCapacity: { type: String, required: true },
    existingBusiness: String,
    message: String,
    status: {
      type: String,
      enum: ["New", "Reviewing", "Approved", "Rejected"],
      default: "New",
    },
  },
  { timestamps: true }
);

export default models.Distributor || model("Distributor", DistributorSchema);
