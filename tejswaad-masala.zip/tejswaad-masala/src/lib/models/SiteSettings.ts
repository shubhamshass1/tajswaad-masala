import { Schema, models, model } from "mongoose";

// A single-document collection holding editable site content, so the owner
// can update text/contact info from the admin panel without a redeploy.
const SiteSettingsSchema = new Schema(
  {
    key: { type: String, default: "main", unique: true },
    heroHeading: { type: String, default: "Tejswaad Masala" },
    heroSubheading: { type: String, default: "Ghar Jaisa Taste" },
    heroDescription: {
      type: String,
      default:
        "Pure, Fresh and Authentic Indian Spices — stone-ground in small batches and delivered straight from Begusarai, Bihar to your kitchen.",
    },
    bannerText: { type: String, default: "" },
    phonePrimary: { type: String, default: "+91 6201540120" },
    phoneSecondary: { type: String, default: "+91 9572267939" },
    email: { type: String, default: "sunitaspiceindustry851126@gmail.com" },
    address: {
      type: String,
      default: "Ward 13, Kiul, Garhara, Teghra, Begusarai, Bihar – 851126, India",
    },
    instagram: { type: String, default: "https://www.instagram.com/tejswaad_masala" },
  },
  { timestamps: true }
);

export default models.SiteSettings || model("SiteSettings", SiteSettingsSchema);
