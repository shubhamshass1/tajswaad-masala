import mongoose, { Schema, models, model } from "mongoose";

const WeightOptionSchema = new Schema(
  {
    weight: { type: String, required: true },
    price: { type: Number, required: true },
    mrp: { type: Number },
    stock: { type: Number, default: 100 },
  },
  { _id: false }
);

const ProductSchema = new Schema(
  {
    slug: { type: String, required: true, unique: true, index: true },
    name: { type: String, required: true },
    category: {
      type: String,
      required: true,
      enum: [
        "Haldi Powder",
        "Mirchi Powder",
        "Dhaniya Powder",
        "Garam Masala",
        "Kitchen King Masala",
        "Jeera Powder",
        "Sabzi Masala",
        "Chaat Masala",
        "Meat Masala",
        "Chicken Masala",
        "Khada Garam Masala",
        "Other Spices",
      ],
    },
    description: { type: String, required: true },
    shortDescription: { type: String, required: true },
    images: [{ type: String }],
    weightOptions: [WeightOptionSchema],
    isBestSeller: { type: Boolean, default: false },
    isNew: { type: Boolean, default: false },
    rating: { type: Number, default: 4.5 },
    reviewCount: { type: Number, default: 0 },
    ingredients: [{ type: String }],
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

export default models.Product || model("Product", ProductSchema);
