import { Schema, models, model } from "mongoose";

const GalleryImageSchema = new Schema(
  {
    url: { type: String, required: true },
    caption: String,
    category: {
      type: String,
      enum: ["Spices", "Factory", "Packaging", "Team"],
      default: "Spices",
    },
  },
  { timestamps: true }
);

export default models.GalleryImage || model("GalleryImage", GalleryImageSchema);
