import { Schema, models, model } from "mongoose";

const TestimonialSchema = new Schema(
  {
    name: { type: String, required: true },
    location: String,
    rating: { type: Number, min: 1, max: 5, default: 5 },
    message: { type: String, required: true },
    image: String,
    isApproved: { type: Boolean, default: false },
  },
  { timestamps: true }
);

export default models.Testimonial || model("Testimonial", TestimonialSchema);
