import { Schema, models, model } from "mongoose";

const BulkOrderSchema = new Schema(
  {
    businessName: { type: String, required: true },
    contactPerson: { type: String, required: true },
    phone: { type: String, required: true },
    email: String,
    businessType: {
      type: String,
      enum: ["Retailer", "Wholesaler", "Restaurant", "Distributor", "Other"],
      required: true,
    },
    city: { type: String, required: true },
    productsInterested: { type: String, required: true },
    estimatedQuantity: { type: String, required: true },
    message: String,
    status: {
      type: String,
      enum: ["New", "Contacted", "Quoted", "Closed"],
      default: "New",
    },
  },
  { timestamps: true }
);

export default models.BulkOrder || model("BulkOrder", BulkOrderSchema);
