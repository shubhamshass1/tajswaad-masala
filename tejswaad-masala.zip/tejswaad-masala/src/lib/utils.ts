import { type ClassValue, clsx } from "clsx";

export function cn(...inputs: ClassValue[]) {
  return clsx(inputs);
}

export function formatINR(amount: number) {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(amount);
}

export function slugify(text: string) {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, "")
    .replace(/[\s_-]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

export function generateOrderNumber() {
  const date = new Date();
  const stamp = `${date.getFullYear()}${String(date.getMonth() + 1).padStart(2, "0")}${String(
    date.getDate()
  ).padStart(2, "0")}`;
  const rand = Math.floor(1000 + Math.random() * 9000);
  return `TJS-${stamp}-${rand}`;
}

export const BUSINESS = {
  name: "Tejswaad Masala",
  tagline: "Ghar Jaisa Taste",
  owner: "Neeraj Kumar",
  type: "Manufacturer & Supplier of Pure & Fresh Spices",
  phonePrimary: "+91 6201540120",
  phonePrimaryRaw: "916201540120",
  phoneSecondary: "+91 9572267939",
  whatsapp: "916201540120",
  email: "sunitaspiceindustry851126@gmail.com",
  address: "Ward 13, Kiul, Garhara, Teghra, Begusarai, Bihar – 851126, India",
  fssai: "2655816159996187",
  instagram: "https://www.instagram.com/tejswaad_masala",
};

export function whatsappLink(message: string) {
  return `https://wa.me/${BUSINESS.whatsapp}?text=${encodeURIComponent(message)}`;
}
