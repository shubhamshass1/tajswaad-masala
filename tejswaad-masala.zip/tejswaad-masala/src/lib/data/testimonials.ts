import { Testimonial, GalleryImage } from "@/types";

export const testimonials: Testimonial[] = [
  {
    _id: "t1",
    name: "Rekha Devi",
    location: "Begusarai, Bihar",
    rating: 5,
    message:
      "Bilkul ghar jaisa swaad! Tejswaad ka garam masala use karne ke baad se bahar ka masala kharidna band kar diya. Aroma aur taste dono lajawab hai.",
    isApproved: true,
    createdAt: new Date().toISOString(),
  },
  {
    _id: "t2",
    name: "Suresh Kumar Sah",
    location: "Kiul, Bihar",
    rating: 5,
    message:
      "As a small hotel owner, quality and consistency matter most. Tejswaad's chicken masala has been consistent batch after batch — my customers keep asking what makes the curry so good!",
    isApproved: true,
    createdAt: new Date().toISOString(),
  },
  {
    _id: "t3",
    name: "Anjali Singh",
    location: "Patna, Bihar",
    rating: 4,
    message:
      "Turmeric powder ka rang aur khushboo dono natural lagte hain. Delivery bhi time par hoti hai. Highly recommend for daily use spices.",
    isApproved: true,
    createdAt: new Date().toISOString(),
  },
  {
    _id: "t4",
    name: "Mohit Traders",
    location: "Teghra, Bihar",
    rating: 5,
    message:
      "We've been sourcing bulk spices from Tejswaad for our retail shop for over a year — reliable supply, fair pricing and always fresh stock.",
    isApproved: true,
    createdAt: new Date().toISOString(),
  },
];

export const galleryImages: GalleryImage[] = [
  { _id: "g1", url: "/images/gallery/spices-1.jpg", category: "Spices", caption: "Freshly ground turmeric", createdAt: new Date().toISOString() },
  { _id: "g2", url: "/images/gallery/spices-2.jpg", category: "Spices", caption: "Whole spice selection", createdAt: new Date().toISOString() },
  { _id: "g3", url: "/images/gallery/factory-1.jpg", category: "Factory", caption: "Grinding unit", createdAt: new Date().toISOString() },
  { _id: "g4", url: "/images/gallery/factory-2.jpg", category: "Factory", caption: "Quality checking", createdAt: new Date().toISOString() },
  { _id: "g5", url: "/images/gallery/packaging-1.jpg", category: "Packaging", caption: "Hygienic packaging line", createdAt: new Date().toISOString() },
  { _id: "g6", url: "/images/gallery/spices-3.jpg", category: "Spices", caption: "Red chilli drying", createdAt: new Date().toISOString() },
];
