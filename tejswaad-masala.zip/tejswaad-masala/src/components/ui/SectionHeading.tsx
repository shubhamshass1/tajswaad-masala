import { cn } from "@/lib/utils";

type Props = {
  eyebrow?: string;
  title: string;
  description?: string;
  align?: "left" | "center";
  light?: boolean;
};

export default function SectionHeading({
  eyebrow,
  title,
  description,
  align = "center",
  light = false,
}: Props) {
  return (
    <div className={cn("max-w-2xl mb-12", align === "center" ? "mx-auto text-center" : "text-left")}>
      {eyebrow && (
        <div
          className={cn(
            "inline-flex items-center gap-2 text-xs font-body font-semibold tracking-[0.25em] uppercase mb-3",
            light ? "text-gold-light" : "text-gold-dark"
          )}
        >
          <span className="h-px w-6 bg-current" />
          {eyebrow}
          <span className="h-px w-6 bg-current" />
        </div>
      )}
      <h2
        className={cn(
          "font-display text-3xl md:text-4xl lg:text-5xl leading-tight",
          light ? "text-cream" : "text-maroon dark:text-cream"
        )}
      >
        {title}
      </h2>
      {description && (
        <p
          className={cn(
            "mt-4 font-body text-base md:text-lg leading-relaxed",
            light ? "text-cream/80" : "text-charcoal/70 dark:text-cream/70"
          )}
        >
          {description}
        </p>
      )}
    </div>
  );
}
