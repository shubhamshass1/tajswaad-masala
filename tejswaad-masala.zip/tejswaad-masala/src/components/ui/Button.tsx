import { ButtonHTMLAttributes, ReactNode } from "react";
import { cn } from "@/lib/utils";

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "secondary" | "outline" | "ghost";
  size?: "sm" | "md" | "lg";
  children: ReactNode;
};

export default function Button({
  variant = "primary",
  size = "md",
  className,
  children,
  ...props
}: ButtonProps) {
  return (
    <button
      className={cn(
        "inline-flex items-center justify-center gap-2 rounded-full font-body font-semibold tracking-wide transition-all duration-300 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold disabled:opacity-50 disabled:pointer-events-none",
        variant === "primary" &&
          "bg-maroon text-cream hover:bg-maroon-dark shadow-premium hover:-translate-y-0.5 hover:shadow-lg",
        variant === "secondary" &&
          "bg-gold text-charcoal hover:bg-gold-light hover:-translate-y-0.5 shadow-gold",
        variant === "outline" &&
          "border-2 border-maroon text-maroon hover:bg-maroon hover:text-cream dark:border-gold dark:text-gold dark:hover:bg-gold dark:hover:text-charcoal",
        variant === "ghost" &&
          "text-maroon hover:bg-maroon/10 dark:text-gold dark:hover:bg-gold/10",
        size === "sm" && "px-4 py-2 text-sm",
        size === "md" && "px-6 py-3 text-base",
        size === "lg" && "px-8 py-4 text-lg",
        className
      )}
      {...props}
    >
      {children}
    </button>
  );
}
