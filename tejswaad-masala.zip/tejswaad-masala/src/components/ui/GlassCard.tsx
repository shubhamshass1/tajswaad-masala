import { HTMLAttributes, ReactNode } from "react";
import { cn } from "@/lib/utils";

export default function GlassCard({
  children,
  className,
  ...props
}: HTMLAttributes<HTMLDivElement> & { children: ReactNode }) {
  return (
    <div
      className={cn(
        "rounded-2xl border border-white/30 bg-white/50 backdrop-blur-xl shadow-glass dark:bg-charcoal/40 dark:border-white/10",
        className
      )}
      {...props}
    >
      {children}
    </div>
  );
}
