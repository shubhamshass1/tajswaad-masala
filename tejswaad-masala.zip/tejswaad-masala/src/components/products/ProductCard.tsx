"use client";

import { useState, useRef, MouseEvent } from "react";
import Image from "next/image";
import Link from "next/link";
import { Heart, ShoppingCart, MessageCircle, Star } from "lucide-react";
import { Product } from "@/types";
import { formatINR, whatsappLink } from "@/lib/utils";
import { useCart } from "@/context/CartContext";
import { useWishlist } from "@/context/WishlistContext";
import Button from "@/components/ui/Button";

export default function ProductCard({ product }: { product: Product }) {
  const cardRef = useRef<HTMLDivElement>(null);
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  const [selectedWeight, setSelectedWeight] = useState(product.weightOptions[0]);
  const { addItem } = useCart();
  const { toggleWishlist, isWishlisted } = useWishlist();

  function handleMouseMove(e: MouseEvent<HTMLDivElement>) {
    const el = cardRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const px = (e.clientX - rect.left) / rect.width - 0.5;
    const py = (e.clientY - rect.top) / rect.height - 0.5;
    setTilt({ x: py * -8, y: px * 8 });
  }

  function resetTilt() {
    setTilt({ x: 0, y: 0 });
  }

  function handleAddToCart() {
    addItem({
      productId: product._id,
      slug: product.slug,
      name: product.name,
      image: product.images[0],
      weight: selectedWeight.weight,
      price: selectedWeight.price,
      quantity: 1,
    });
  }

  return (
    <div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={resetTilt}
      style={{ transform: `perspective(900px) rotateX(${tilt.x}deg) rotateY(${tilt.y}deg)` }}
      className="group relative rounded-2xl bg-white/80 dark:bg-white/5 border border-gold/20 shadow-glass hover:shadow-premium transition-shadow duration-300 overflow-hidden [transform-style:preserve-3d]"
    >
      {(product.isBestSeller || product.isNew) && (
        <span className="absolute top-3 left-3 z-10 text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full bg-chili text-white">
          {product.isBestSeller ? "Best Seller" : "New"}
        </span>
      )}
      <button
        onClick={() => toggleWishlist(product._id)}
        aria-label="Toggle wishlist"
        className="absolute top-3 right-3 z-10 w-8 h-8 rounded-full bg-white/80 dark:bg-charcoal/70 flex items-center justify-center hover:scale-110 transition-transform"
      >
        <Heart
          className="w-4 h-4"
          fill={isWishlisted(product._id) ? "#C1272D" : "none"}
          color={isWishlisted(product._id) ? "#C1272D" : "#231810"}
        />
      </button>

      <Link href={`/products/${product.slug}`}>
        <div className="relative aspect-square bg-cream-dark/50 overflow-hidden">
          <Image
            src={product.images[0]}
            alt={product.name}
            fill
            className="object-cover group-hover:scale-110 transition-transform duration-500"
            sizes="(max-width: 768px) 50vw, 25vw"
          />
        </div>
      </Link>

      <div className="p-4">
        <Link href={`/products/${product.slug}`}>
          <h3 className="font-display text-lg text-charcoal dark:text-cream leading-tight hover:text-maroon dark:hover:text-gold-light transition-colors">
            {product.name}
          </h3>
        </Link>
        <p className="text-xs text-charcoal/60 dark:text-cream/60 mt-1 line-clamp-2">
          {product.shortDescription}
        </p>

        {product.rating && (
          <div className="flex items-center gap-1 mt-2">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star
                key={i}
                className="w-3.5 h-3.5"
                fill={i < Math.round(product.rating!) ? "#C9A227" : "none"}
                color="#C9A227"
              />
            ))}
            <span className="text-[11px] text-charcoal/50 dark:text-cream/50 ml-1">
              ({product.reviewCount})
            </span>
          </div>
        )}

        <div className="flex flex-wrap gap-1.5 mt-3">
          {product.weightOptions.map((w) => (
            <button
              key={w.weight}
              onClick={() => setSelectedWeight(w)}
              className={`text-[11px] px-2.5 py-1 rounded-full border transition-colors ${
                selectedWeight.weight === w.weight
                  ? "bg-maroon text-cream border-maroon"
                  : "border-charcoal/20 dark:border-cream/20 text-charcoal/70 dark:text-cream/70"
              }`}
            >
              {w.weight}
            </button>
          ))}
        </div>

        <div className="flex items-baseline gap-2 mt-3">
          <span className="font-display text-xl text-maroon dark:text-gold-light">
            {formatINR(selectedWeight.price)}
          </span>
          {selectedWeight.mrp && (
            <span className="text-xs text-charcoal/40 dark:text-cream/40 line-through">
              {formatINR(selectedWeight.mrp)}
            </span>
          )}
        </div>

        <div className="grid grid-cols-2 gap-2 mt-4">
          <Button size="sm" variant="outline" onClick={handleAddToCart} className="!px-2">
            <ShoppingCart className="w-3.5 h-3.5" /> Add
          </Button>
          <Link href={`/checkout?buyNow=${product._id}&weight=${selectedWeight.weight}`}>
            <Button size="sm" className="w-full !px-2">
              Buy Now
            </Button>
          </Link>
        </div>
        <a
          href={whatsappLink(
            `Hi, I want to order ${product.name} (${selectedWeight.weight}) - ${formatINR(
              selectedWeight.price
            )}`
          )}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-2 flex items-center justify-center gap-1.5 text-xs font-medium text-[#1a8f4c] dark:text-[#25D366] hover:underline"
        >
          <MessageCircle className="w-3.5 h-3.5" /> Order via WhatsApp
        </a>
      </div>
    </div>
  );
}
