"use client";

import { Search } from "lucide-react";
import { categories } from "@/lib/data/products";
import { cn } from "@/lib/utils";

type Props = {
  search: string;
  onSearch: (v: string) => void;
  activeCategory: string;
  onCategory: (c: string) => void;
  sort: string;
  onSort: (s: string) => void;
};

export default function ProductFilters({
  search,
  onSearch,
  activeCategory,
  onCategory,
  sort,
  onSort,
}: Props) {
  return (
    <div className="mb-10 space-y-5">
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-charcoal/40 dark:text-cream/40" />
          <input
            value={search}
            onChange={(e) => onSearch(e.target.value)}
            placeholder="Search for haldi, garam masala, chicken masala..."
            className="w-full pl-11 pr-4 py-3 rounded-full bg-white/70 dark:bg-white/5 border border-gold/20 focus:outline-none focus:ring-2 focus:ring-gold text-sm"
          />
        </div>
        <select
          value={sort}
          onChange={(e) => onSort(e.target.value)}
          className="px-4 py-3 rounded-full bg-white/70 dark:bg-white/5 border border-gold/20 focus:outline-none focus:ring-2 focus:ring-gold text-sm"
        >
          <option value="popular">Sort: Popular</option>
          <option value="price-low">Price: Low to High</option>
          <option value="price-high">Price: High to Low</option>
          <option value="rating">Highest Rated</option>
        </select>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-none">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => onCategory(cat)}
            className={cn(
              "shrink-0 px-4 py-2 rounded-full text-sm font-medium border transition-colors",
              activeCategory === cat
                ? "bg-maroon text-cream border-maroon"
                : "border-gold/20 text-charcoal/70 dark:text-cream/70 hover:border-gold/50"
            )}
          >
            {cat}
          </button>
        ))}
      </div>
    </div>
  );
}
