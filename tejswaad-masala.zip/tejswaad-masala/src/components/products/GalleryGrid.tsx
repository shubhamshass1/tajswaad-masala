"use client";

import { useState } from "react";
import Image from "next/image";
import { motion, AnimatePresence } from "framer-motion";
import { X, ChevronLeft, ChevronRight } from "lucide-react";
import { GalleryImage } from "@/types";
import RevealOnScroll from "@/components/ui/RevealOnScroll";

const FILTERS = ["All", "Spices", "Factory", "Packaging", "Team"] as const;

export default function GalleryGrid({ images }: { images: GalleryImage[] }) {
  const [filter, setFilter] = useState<(typeof FILTERS)[number]>("All");
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  const filtered = filter === "All" ? images : images.filter((i) => i.category === filter);

  return (
    <div>
      <div className="flex flex-wrap justify-center gap-2 mb-10">
        {FILTERS.map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-4 py-1.5 rounded-full text-sm font-medium border transition-colors ${
              filter === f
                ? "bg-maroon text-cream border-maroon"
                : "border-gold/30 text-charcoal/70 dark:text-cream/70 hover:border-gold"
            }`}
          >
            {f}
          </button>
        ))}
      </div>

      <div className="columns-2 md:columns-3 gap-4 space-y-4">
        {filtered.map((img, i) => (
          <RevealOnScroll key={img._id} delay={(i % 6) * 0.05}>
            <button
              onClick={() => setActiveIndex(i)}
              className="block w-full break-inside-avoid rounded-2xl overflow-hidden shadow-glass hover:shadow-premium transition-shadow group relative"
            >
              <div className="relative aspect-[4/3]">
                <Image
                  src={img.url}
                  alt={img.caption ?? "Tejswaad Masala"}
                  fill
                  className="object-cover group-hover:scale-110 transition-transform duration-500"
                />
              </div>
              {img.caption && (
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-3 text-left">
                  <p className="text-xs text-white font-medium">{img.caption}</p>
                </div>
              )}
            </button>
          </RevealOnScroll>
        ))}
      </div>

      <AnimatePresence>
        {activeIndex !== null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-black/90 flex items-center justify-center p-6"
            onClick={() => setActiveIndex(null)}
          >
            <button
              className="absolute top-6 right-6 text-white/80 hover:text-white"
              onClick={() => setActiveIndex(null)}
              aria-label="Close"
            >
              <X className="w-8 h-8" />
            </button>
            <button
              className="absolute left-4 md:left-8 text-white/70 hover:text-white"
              onClick={(e) => {
                e.stopPropagation();
                setActiveIndex((i) => (i! - 1 + filtered.length) % filtered.length);
              }}
              aria-label="Previous image"
            >
              <ChevronLeft className="w-9 h-9" />
            </button>
            <button
              className="absolute right-4 md:right-8 text-white/70 hover:text-white"
              onClick={(e) => {
                e.stopPropagation();
                setActiveIndex((i) => (i! + 1) % filtered.length);
              }}
              aria-label="Next image"
            >
              <ChevronRight className="w-9 h-9" />
            </button>
            <motion.div
              key={activeIndex}
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="relative w-full max-w-3xl aspect-[4/3]"
              onClick={(e) => e.stopPropagation()}
            >
              <Image
                src={filtered[activeIndex].url}
                alt={filtered[activeIndex].caption ?? "Tejswaad Masala"}
                fill
                className="object-contain"
              />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
