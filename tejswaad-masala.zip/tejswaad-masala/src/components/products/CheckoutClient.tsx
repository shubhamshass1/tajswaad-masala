"use client";

import { useState, useMemo, FormEvent, useEffect } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import Image from "next/image";
import Script from "next/script";
import { Loader2 } from "lucide-react";
import Button from "@/components/ui/Button";
import { useCart } from "@/context/CartContext";
import { products } from "@/lib/data/products";
import { formatINR } from "@/lib/utils";
import { CartItem } from "@/types";

declare global {
  interface Window {
    Razorpay: new (options: Record<string, unknown>) => {
      open: () => void;
    };
  }
}

export default function CheckoutClient() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { items: cartItems, clearCart } = useCart();
  const [loading, setLoading] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<"COD" | "Razorpay">("COD");
  const [form, setForm] = useState({
    name: "",
    phone: "",
    email: "",
    address: "",
    city: "",
    state: "Bihar",
    pincode: "",
  });

  const buyNowId = searchParams.get("buyNow");
  const buyNowWeight = searchParams.get("weight");
  const buyNowQty = Math.max(1, Number(searchParams.get("qty")) || 1);

  const items: CartItem[] = useMemo(() => {
    if (buyNowId) {
      const p = products.find((prod) => prod._id === buyNowId);
      if (!p) return [];
      const w = p.weightOptions.find((wo) => wo.weight === buyNowWeight) ?? p.weightOptions[0];
      return [
        {
          productId: p._id,
          slug: p.slug,
          name: p.name,
          image: p.images[0],
          weight: w.weight,
          price: w.price,
          quantity: buyNowQty,
        },
      ];
    }
    return cartItems;
  }, [buyNowId, buyNowWeight, buyNowQty, cartItems]);

  useEffect(() => {
    if (!buyNowId && cartItems.length === 0) router.replace("/products");
  }, [buyNowId, cartItems.length, router]);

  const subtotal = items.reduce((s, i) => s + i.price * i.quantity, 0);
  const shipping = subtotal >= 499 ? 0 : 49;
  const total = subtotal + shipping;

  function update<K extends keyof typeof form>(key: K, value: string) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function placeOrder(paymentStatus: "Pending" | "Paid", razorpayIds?: Record<string, string>) {
    const res = await fetch("/api/orders", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        customer: form,
        items,
        subtotal,
        shipping,
        total,
        paymentMethod,
        paymentStatus,
        ...razorpayIds,
      }),
    });
    const data = await res.json();
    if (!buyNowId) clearCart();
    router.push(`/order-success?order=${data.orderNumber ?? ""}`);
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      if (paymentMethod === "COD") {
        await placeOrder("Pending");
        return;
      }

      // Razorpay flow
      const orderRes = await fetch("/api/razorpay/create-order", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ amount: total }),
      });
      const order = await orderRes.json();

      const rzp = new window.Razorpay({
        key: process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID,
        amount: order.amount,
        currency: "INR",
        name: "Tejswaad Masala",
        description: "Order Payment",
        order_id: order.id,
        prefill: { name: form.name, contact: form.phone, email: form.email },
        theme: { color: "#8B0F13" },
        handler: async (response: {
          razorpay_order_id: string;
          razorpay_payment_id: string;
        }) => {
          await placeOrder("Paid", {
            razorpayOrderId: response.razorpay_order_id,
            razorpayPaymentId: response.razorpay_payment_id,
          });
        },
      });
      rzp.open();
    } catch {
      alert("Something went wrong placing your order. Please try again or contact us on WhatsApp.");
    } finally {
      setLoading(false);
    }
  }

  if (items.length === 0) return null;

  return (
    <div className="pt-28 pb-20 bg-cream dark:bg-charcoal min-h-screen">
      <Script src="https://checkout.razorpay.com/v1/checkout.js" strategy="lazyOnload" />
      <div className="mx-auto max-w-5xl px-6 md:px-8">
        <h1 className="font-display text-3xl text-maroon dark:text-cream mb-8">Checkout</h1>
        <form onSubmit={handleSubmit} className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <div className="p-6 rounded-2xl bg-white/70 dark:bg-white/5 border border-gold/20">
              <h3 className="font-display text-lg text-charcoal dark:text-cream mb-4">
                Delivery Details
              </h3>
              <div className="grid sm:grid-cols-2 gap-4">
                <input required placeholder="Full Name" value={form.name} onChange={(e) => update("name", e.target.value)} className={inputClass} />
                <input required type="tel" placeholder="Phone Number" value={form.phone} onChange={(e) => update("phone", e.target.value)} className={inputClass} />
                <input type="email" placeholder="Email (optional)" value={form.email} onChange={(e) => update("email", e.target.value)} className={`${inputClass} sm:col-span-2`} />
                <textarea required placeholder="Full Address" rows={2} value={form.address} onChange={(e) => update("address", e.target.value)} className={`${inputClass} sm:col-span-2`} />
                <input required placeholder="City" value={form.city} onChange={(e) => update("city", e.target.value)} className={inputClass} />
                <input required placeholder="State" value={form.state} onChange={(e) => update("state", e.target.value)} className={inputClass} />
                <input required placeholder="Pincode" value={form.pincode} onChange={(e) => update("pincode", e.target.value)} className={inputClass} />
              </div>
            </div>

            <div className="p-6 rounded-2xl bg-white/70 dark:bg-white/5 border border-gold/20">
              <h3 className="font-display text-lg text-charcoal dark:text-cream mb-4">
                Payment Method
              </h3>
              <div className="grid sm:grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setPaymentMethod("COD")}
                  className={`p-4 rounded-xl border text-left ${
                    paymentMethod === "COD" ? "border-maroon bg-maroon/5" : "border-gold/20"
                  }`}
                >
                  <p className="font-medium text-charcoal dark:text-cream">Cash on Delivery</p>
                  <p className="text-xs text-charcoal/60 dark:text-cream/60">Pay when your order arrives</p>
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod("Razorpay")}
                  className={`p-4 rounded-xl border text-left ${
                    paymentMethod === "Razorpay" ? "border-maroon bg-maroon/5" : "border-gold/20"
                  }`}
                >
                  <p className="font-medium text-charcoal dark:text-cream">Pay Online</p>
                  <p className="text-xs text-charcoal/60 dark:text-cream/60">UPI, Cards, Netbanking via Razorpay</p>
                </button>
              </div>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-white/70 dark:bg-white/5 border border-gold/20 h-fit sticky top-28">
            <h3 className="font-display text-lg text-charcoal dark:text-cream mb-4">Order Summary</h3>
            <div className="space-y-3 max-h-56 overflow-y-auto pr-1">
              {items.map((item) => (
                <div key={`${item.productId}-${item.weight}`} className="flex gap-3 text-sm">
                  <div className="relative w-12 h-12 rounded-lg overflow-hidden shrink-0 bg-cream-dark">
                    <Image src={item.image} alt={item.name} fill className="object-cover" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="truncate text-charcoal dark:text-cream">{item.name}</p>
                    <p className="text-xs text-charcoal/50 dark:text-cream/50">
                      {item.weight} x {item.quantity}
                    </p>
                  </div>
                  <p className="text-charcoal dark:text-cream">{formatINR(item.price * item.quantity)}</p>
                </div>
              ))}
            </div>
            <div className="space-y-2 text-sm text-charcoal/70 dark:text-cream/70 mt-4 pt-4 border-t border-gold/20">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span>{formatINR(subtotal)}</span>
              </div>
              <div className="flex justify-between">
                <span>Shipping</span>
                <span>{shipping === 0 ? "Free" : formatINR(shipping)}</span>
              </div>
            </div>
            <div className="flex justify-between font-display text-lg text-maroon dark:text-gold-light mt-3 pt-3 border-t border-gold/20">
              <span>Total</span>
              <span>{formatINR(total)}</span>
            </div>
            <Button type="submit" size="lg" disabled={loading} className="w-full mt-6">
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Place Order"}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}

const inputClass =
  "w-full px-4 py-2.5 rounded-lg bg-white/70 dark:bg-white/5 border border-gold/20 focus:outline-none focus:ring-2 focus:ring-gold text-sm text-charcoal dark:text-cream";
