"use client";

import { useState } from "react";
import Link from "next/link";
import { ShoppingCart, MessageCircle, Star, Heart, ShieldCheck, Truck } from "lucide-react";
import { Product } from "@/types";
import { formatINR, whatsappLink } from "@/lib/utils";
import { useCart } from "@/context/CartContext";
import { useWishlist } from "@/context/WishlistContext";
import Button from "@/components/ui/Button";

export default function ProductDetailClient({ product }: { product: Product }) {
  const [selectedWeight, setSelectedWeight] = useState(product.weightOptions[0]);
  const [quantity, setQuantity] = useState(1);
  const { addItem } = useCart();
  const { toggleWishlist, isWishlisted } = useWishlist();

  function handleAddToCart() {
    addItem({
      productId: product._id,
      slug: product.slug,
      name: product.name,
      image: product.images[0],
      weight: selectedWeight.weight,
      price: selectedWeight.price,
      quantity,
    });
  }

  return (
    <div>
      {product.rating && (
        <div className="flex items-center gap-1 mb-3">
          {Array.from({ length: 5 }).map((_, i) => (
            <Star key={i} className="w-4 h-4" fill={i < Math.round(product.rating!) ? "#C9A227" : "none"} color="#C9A227" />
          ))}
          <span className="text-sm text-charcoal/50 dark:text-cream/50 ml-1">
            {product.rating} ({product.reviewCount} reviews)
          </span>
        </div>
      )}

      <h1 className="font-display text-3xl md:text-4xl text-maroon dark:text-cream mb-3">
        {product.name}
      </h1>
      <p className="text-charcoal/70 dark:text-cream/70 leading-relaxed mb-6">
        {product.description}
      </p>

      {product.ingredients && (
        <div className="mb-6">
          <p className="text-xs font-semibold uppercase tracking-wide text-charcoal/50 dark:text-cream/50 mb-2">
            Key Ingredients
          </p>
          <div className="flex flex-wrap gap-2">
            {product.ingredients.map((ing) => (
              <span key={ing} className="text-xs px-3 py-1 rounded-full bg-forest/10 text-forest dark:bg-gold/10 dark:text-gold-light">
                {ing}
              </span>
            ))}
          </div>
        </div>
      )}

      <div className="mb-6">
        <p className="text-xs font-semibold uppercase tracking-wide text-charcoal/50 dark:text-cream/50 mb-2">
          Select Weight
        </p>
        <div className="flex flex-wrap gap-2">
          {product.weightOptions.map((w) => (
            <button
              key={w.weight}
              onClick={() => setSelectedWeight(w)}
              className={`px-4 py-2 rounded-lg border text-sm font-medium transition-colors ${
                selectedWeight.weight === w.weight
                  ? "bg-maroon text-cream border-maroon"
                  : "border-gold/30 text-charcoal dark:text-cream hover:border-gold"
              }`}
            >
              {w.weight} — {formatINR(w.price)}
            </button>
          ))}
        </div>
      </div>

      <div className="flex items-baseline gap-3 mb-6">
        <span className="font-display text-3xl text-maroon dark:text-gold-light">
          {formatINR(selectedWeight.price)}
        </span>
        {selectedWeight.mrp && (
          <span className="text-lg text-charcoal/40 dark:text-cream/40 line-through">
            {formatINR(selectedWeight.mrp)}
          </span>
        )}
        <span className="text-xs text-charcoal/50 dark:text-cream/50">Inclusive of all taxes</span>
      </div>

      <div className="flex items-center gap-4 mb-6">
        <div className="flex items-center border border-gold/30 rounded-full">
          <button onClick={() => setQuantity((q) => Math.max(1, q - 1))} className="w-9 h-9 flex items-center justify-center text-lg">
            −
          </button>
          <span className="w-8 text-center text-sm">{quantity}</span>
          <button onClick={() => setQuantity((q) => q + 1)} className="w-9 h-9 flex items-center justify-center text-lg">
            +
          </button>
        </div>
        <button
          onClick={() => toggleWishlist(product._id)}
          className="w-11 h-11 rounded-full border border-gold/30 flex items-center justify-center"
          aria-label="Toggle wishlist"
        >
          <Heart className="w-5 h-5" fill={isWishlisted(product._id) ? "#C1272D" : "none"} color="#C1272D" />
        </button>
      </div>

      <div className="grid sm:grid-cols-2 gap-3 mb-6">
        <Button size="lg" variant="outline" onClick={handleAddToCart}>
          <ShoppingCart className="w-4 h-4" /> Add to Cart
        </Button>
        <Link href={`/checkout?buyNow=${product._id}&weight=${selectedWeight.weight}&qty=${quantity}`}>
          <Button size="lg" className="w-full">
            Buy Now
          </Button>
        </Link>
      </div>

      <a
        href={whatsappLink(
          `Hi, I want to order ${product.name} (${selectedWeight.weight} x${quantity}) - ${formatINR(
            selectedWeight.price * quantity
          )}`
        )}
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center justify-center gap-2 text-sm font-medium text-[#1a8f4c] dark:text-[#25D366] hover:underline mb-8"
      >
        <MessageCircle className="w-4 h-4" /> Order via WhatsApp Instead
      </a>

      <div className="flex flex-col sm:flex-row gap-4 text-xs text-charcoal/60 dark:text-cream/60 border-t border-gold/20 pt-6">
        <span className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-forest" /> FSSAI Certified & 100% Natural
        </span>
        <span className="flex items-center gap-2">
          <Truck className="w-4 h-4 text-forest" /> Pan-India Delivery
        </span>
      </div>
    </div>
  );
}
