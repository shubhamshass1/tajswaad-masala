"use client";

import { useState, useMemo, useEffect } from "react";
import { useSearchParams } from "next/navigation";
import ProductFilters from "./ProductFilters";
import ProductCard from "./ProductCard";
import { products as allProducts } from "@/lib/data/products";
import { PackageSearch } from "lucide-react";

export default function ProductGrid() {
  const searchParams = useSearchParams();
  const initialCategory = searchParams.get("category") ?? "All";

  const [search, setSearch] = useState("");
  const [category, setCategory] = useState(initialCategory);
  const [sort, setSort] = useState("popular");

  useEffect(() => {
    const c = searchParams.get("category");
    if (c) setCategory(c);
  }, [searchParams]);

  const filtered = useMemo(() => {
    let list = allProducts.filter((p) => p.isActive);
    if (category !== "All") list = list.filter((p) => p.category === category);
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q) ||
          p.shortDescription.toLowerCase().includes(q)
      );
    }
    switch (sort) {
      case "price-low":
        list = [...list].sort((a, b) => a.weightOptions[0].price - b.weightOptions[0].price);
        break;
      case "price-high":
        list = [...list].sort((a, b) => b.weightOptions[0].price - a.weightOptions[0].price);
        break;
      case "rating":
        list = [...list].sort((a, b) => (b.rating ?? 0) - (a.rating ?? 0));
        break;
      default:
        list = [...list].sort((a, b) => Number(b.isBestSeller) - Number(a.isBestSeller));
    }
    return list;
  }, [search, category, sort]);

  return (
    <div>
      <ProductFilters
        search={search}
        onSearch={setSearch}
        activeCategory={category}
        onCategory={setCategory}
        sort={sort}
        onSort={setSort}
      />

      {filtered.length === 0 ? (
        <div className="text-center py-20 text-charcoal/50 dark:text-cream/50">
          <PackageSearch className="w-10 h-10 mx-auto mb-3" />
          <p>No products found. Try a different search or category.</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
          {filtered.map((p) => (
            <ProductCard key={p._id} product={p} />
          ))}
        </div>
      )}
    </div>
  );
}
