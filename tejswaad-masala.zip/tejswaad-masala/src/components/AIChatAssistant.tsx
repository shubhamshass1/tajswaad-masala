"use client";

import { useState, useRef, useEffect } from "react";
import { usePathname } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { Bot, X, Send } from "lucide-react";
import { BUSINESS, whatsappLink } from "@/lib/utils";

type Message = { role: "bot" | "user"; text: string };

const FAQ: { keywords: string[]; answer: string }[] = [
  {
    keywords: ["price", "cost", "rate"],
    answer:
      "Our spice prices start from just ₹35 for a 100g pack. Visit the Products page to see prices for every weight option, or tell me which spice you're looking for!",
  },
  {
    keywords: ["bulk", "wholesale", "distributor", "dealer"],
    answer:
      "We supply in bulk to retailers, restaurants and distributors across Bihar. Please visit our Bulk Order page to submit an inquiry, or I can connect you on WhatsApp right now.",
  },
  {
    keywords: ["delivery", "shipping", "ship"],
    answer:
      "We deliver across India. Orders are usually packed within 24 hours and delivered in 3-7 business days depending on your location.",
  },
  {
    keywords: ["payment", "cod", "cash on delivery"],
    answer:
      "We accept both Cash on Delivery and secure online payments via Razorpay (UPI, cards, netbanking).",
  },
  {
    keywords: ["contact", "phone", "number", "email"],
    answer: `You can reach us at ${BUSINESS.phonePrimary} / ${BUSINESS.phoneSecondary} or email ${BUSINESS.email}.`,
  },
  {
    keywords: ["fssai", "license", "certified", "quality"],
    answer: `Yes, we're a fully FSSAI licensed manufacturer (License No. ${BUSINESS.fssai}). All our spices are 100% natural, pure and fresh.`,
  },
  {
    keywords: ["haldi", "turmeric"],
    answer: "Our Haldi Powder is stone-ground for deep colour and aroma — available in 100g to 1kg packs starting at ₹45.",
  },
  {
    keywords: ["garam masala"],
    answer: "Our signature Garam Masala is a hand-roasted blend of 15+ whole spices — a customer favourite! Starting at ₹60 for 50g.",
  },
];

function getBotReply(input: string): string {
  const lower = input.toLowerCase();
  const match = FAQ.find((f) => f.keywords.some((k) => lower.includes(k)));
  if (match) return match.answer;
  return "Thanks for reaching out! For a quick and detailed answer, I'd recommend chatting with our team directly on WhatsApp — tap the button below.";
}

export default function AIChatAssistant() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "bot",
      text: "Namaste! 🙏 I'm the Tejswaad assistant. Ask me about our spices, prices, bulk orders or delivery.",
    },
  ]);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, open]);

  if (pathname?.startsWith("/admin")) return null;

  function handleSend() {
    if (!input.trim()) return;
    const userMsg: Message = { role: "user", text: input.trim() };
    const botMsg: Message = { role: "bot", text: getBotReply(input) };
    setMessages((prev) => [...prev, userMsg, botMsg]);
    setInput("");
  }

  return (
    <div className="fixed bottom-24 left-6 z-40 md:bottom-6 md:left-auto md:right-24">
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="mb-3 w-[90vw] max-w-sm h-[420px] rounded-2xl bg-cream dark:bg-charcoal border border-gold/30 shadow-premium flex flex-col overflow-hidden"
          >
            <div className="bg-maroon text-cream px-4 py-3 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Bot className="w-5 h-5 text-gold-light" />
                <span className="font-display text-sm">Tejswaad Assistant</span>
              </div>
              <button onClick={() => setOpen(false)} aria-label="Close chat">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-3 text-sm">
              {messages.map((m, i) => (
                <div
                  key={i}
                  className={cnMsg(m.role)}
                >
                  {m.text}
                </div>
              ))}
              <div ref={endRef} />
            </div>
            <div className="p-3 border-t border-gold/20 flex gap-2">
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSend()}
                placeholder="Ask about our spices..."
                className="flex-1 rounded-full px-4 py-2 text-sm bg-white/70 dark:bg-white/10 border border-gold/20 focus:outline-none focus:ring-2 focus:ring-gold"
              />
              <button
                onClick={handleSend}
                aria-label="Send"
                className="w-9 h-9 rounded-full bg-maroon text-cream flex items-center justify-center shrink-0"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
            <a
              href={whatsappLink("Hi, I have a question about Tejswaad Masala products.")}
              target="_blank"
              rel="noopener noreferrer"
              className="text-center text-xs py-2 bg-[#25D366]/10 text-[#1a8f4c] dark:text-[#25D366] font-medium"
            >
              Continue on WhatsApp →
            </a>
          </motion.div>
        )}
      </AnimatePresence>

      <button
        onClick={() => setOpen((v) => !v)}
        aria-label="Open chat assistant"
        className="w-14 h-14 rounded-full bg-gold text-charcoal shadow-gold flex items-center justify-center hover:scale-110 transition-transform"
      >
        <Bot className="w-6 h-6" />
      </button>
    </div>
  );
}

function cnMsg(role: "bot" | "user") {
  return role === "bot"
    ? "bg-white/70 dark:bg-white/10 text-charcoal dark:text-cream rounded-2xl rounded-tl-sm px-3 py-2 max-w-[85%]"
    : "bg-maroon text-cream rounded-2xl rounded-tr-sm px-3 py-2 max-w-[85%] ml-auto";
}
