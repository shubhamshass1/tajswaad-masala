"use client";

import { usePathname } from "next/navigation";
import { Phone } from "lucide-react";
import { BUSINESS } from "@/lib/utils";

export default function CallButton() {
  const pathname = usePathname();
  if (pathname?.startsWith("/admin")) return null;

  return (
    <a
      href={`tel:${BUSINESS.phonePrimary}`}
      aria-label="Call Now"
      className="fixed bottom-6 right-6 z-40 flex items-center justify-center w-14 h-14 rounded-full bg-maroon text-cream shadow-premium hover:scale-110 transition-transform"
    >
      <Phone className="w-6 h-6" />
    </a>
  );
}
