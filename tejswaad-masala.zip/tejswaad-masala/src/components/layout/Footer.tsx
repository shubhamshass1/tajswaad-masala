"use client";

import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { Phone, Mail, MapPin, Instagram, MessageCircle } from "lucide-react";
import { BUSINESS, whatsappLink } from "@/lib/utils";

export default function Footer() {
  const pathname = usePathname();
  if (pathname?.startsWith("/admin")) return null;

  return (
    <footer className="relative bg-maroon-dark text-cream pt-16 pb-8 overflow-hidden">
      <div
        className="absolute inset-0 opacity-[0.06] pointer-events-none"
        style={{
          backgroundImage:
            "radial-gradient(circle at 20% 20%, #C9A227 0, transparent 45%), radial-gradient(circle at 80% 60%, #C9A227 0, transparent 45%)",
        }}
      />
      <div className="relative mx-auto max-w-7xl px-6 md:px-8 grid grid-cols-1 md:grid-cols-4 gap-10">
        <div>
          <Image
            src="/images/logo.png"
            alt="Tejswaad Masala"
            width={160}
            height={76}
            className="h-14 w-auto object-contain brightness-0 invert opacity-95 mb-4"
          />
          <p className="font-accent italic text-gold-light text-lg mb-4">Ghar Jaisa Taste</p>
          <p className="text-cream/70 text-sm leading-relaxed">
            {BUSINESS.type}. Trusted by families and businesses across Bihar for pure, fresh and
            authentic spices.
          </p>
          <a
            href={BUSINESS.instagram}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 mt-4 text-sm text-gold-light hover:text-gold transition"
          >
            <Instagram className="w-4 h-4" /> @tejswaad_masala
          </a>
        </div>

        <div>
          <h4 className="font-display text-lg text-gold-light mb-4">Quick Links</h4>
          <ul className="space-y-2 text-sm text-cream/80">
            {[
              ["/about", "About Us"],
              ["/products", "Products"],
              ["/bulk-order", "Bulk Order"],
              ["/distributor", "Become a Distributor"],
              ["/gallery", "Gallery"],
              ["/testimonials", "Testimonials"],
            ].map(([href, label]) => (
              <li key={href}>
                <Link href={href} className="hover:text-gold-light transition">
                  {label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="font-display text-lg text-gold-light mb-4">Categories</h4>
          <ul className="space-y-2 text-sm text-cream/80">
            {["Haldi Powder", "Mirchi Powder", "Garam Masala", "Chicken Masala", "Chaat Masala"].map(
              (c) => (
                <li key={c}>
                  <Link href="/products" className="hover:text-gold-light transition">
                    {c}
                  </Link>
                </li>
              )
            )}
          </ul>
        </div>

        <div>
          <h4 className="font-display text-lg text-gold-light mb-4">Contact Us</h4>
          <ul className="space-y-3 text-sm text-cream/80">
            <li className="flex items-start gap-2">
              <MapPin className="w-4 h-4 mt-0.5 shrink-0 text-gold-light" />
              {BUSINESS.address}
            </li>
            <li className="flex items-center gap-2">
              <Phone className="w-4 h-4 shrink-0 text-gold-light" />
              <a href={`tel:${BUSINESS.phonePrimary}`} className="hover:text-gold-light">
                {BUSINESS.phonePrimary}
              </a>
              {" / "}
              <a href={`tel:${BUSINESS.phoneSecondary}`} className="hover:text-gold-light">
                {BUSINESS.phoneSecondary}
              </a>
            </li>
            <li className="flex items-center gap-2">
              <Mail className="w-4 h-4 shrink-0 text-gold-light" />
              <a href={`mailto:${BUSINESS.email}`} className="hover:text-gold-light break-all">
                {BUSINESS.email}
              </a>
            </li>
            <li>
              <a
                href={whatsappLink("Hi Tejswaad Masala, I'd like to know more about your products.")}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 mt-1 text-forest bg-cream px-3 py-1.5 rounded-full text-xs font-semibold hover:bg-gold-light transition"
              >
                <MessageCircle className="w-3.5 h-3.5" /> Chat on WhatsApp
              </a>
            </li>
          </ul>
        </div>
      </div>

      <div className="relative mt-12 pt-6 border-t border-cream/15 mx-6 md:mx-8 flex flex-col md:flex-row items-center justify-between gap-3 text-xs text-cream/60">
        <p>© {new Date().getFullYear()} Tejswaad Masala. All rights reserved. Owner: {BUSINESS.owner}</p>
        <p>FSSAI License No. {BUSINESS.fssai}</p>
      </div>
    </footer>
  );
}
