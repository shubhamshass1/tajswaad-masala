import { cn } from "@/lib/utils";

type Props = {
  flip?: boolean;
  fill?: string; // tailwind text-color class controlling the SVG fill via currentColor
  className?: string;
};

/**
 * Signature brand motif: a curved gold-trimmed arch, echoing the sweeping
 * gold border that frames the spice photograph on the original Tejswaad
 * visiting card. Used throughout the site as a section divider instead of a
 * generic straight line or wave.
 */
export default function ArchDivider({ flip = false, fill = "text-cream", className }: Props) {
  return (
    <div className={cn("relative w-full overflow-hidden leading-[0]", flip && "rotate-180", className)}>
      <svg
        viewBox="0 0 1440 120"
        preserveAspectRatio="none"
        className={cn("w-full h-[70px] md:h-[110px]", fill)}
      >
        <path
          d="M0,120 L0,60 C240,10 480,0 720,0 C960,0 1200,10 1440,60 L1440,120 Z"
          fill="currentColor"
        />
        <path
          d="M0,60 C240,10 480,0 720,0 C960,0 1200,10 1440,60"
          fill="none"
          stroke="#C9A227"
          strokeWidth="3"
        />
      </svg>
    </div>
  );
}
