"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X, Search, Heart, ShoppingBag } from "lucide-react";
import { cn } from "@/lib/utils";
import { useCart } from "@/context/CartContext";
import ThemeToggle from "./ThemeToggle";

const NAV_LINKS = [
  { href: "/", label: "Home" },
  { href: "/about", label: "About" },
  { href: "/products", label: "Products" },
  { href: "/bulk-order", label: "Bulk Order" },
  { href: "/distributor", label: "Distributor" },
  { href: "/gallery", label: "Gallery" },
  { href: "/testimonials", label: "Testimonials" },
  { href: "/contact", label: "Contact" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const pathname = usePathname();
  const { itemCount, setCartOpen } = useCart();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => setOpen(false), [pathname]);

  if (pathname?.startsWith("/admin")) return null;

  return (
    <header
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300",
        scrolled
          ? "bg-cream/90 dark:bg-charcoal/90 backdrop-blur-lg shadow-glass py-2"
          : "bg-transparent py-4"
      )}
    >
      <nav className="mx-auto max-w-7xl px-4 md:px-8 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 shrink-0">
          <Image
            src="/images/logo.png"
            alt="Tejswaad Masala"
            width={140}
            height={66}
            className="h-10 md:h-12 w-auto object-contain"
            priority
          />
        </Link>

        <div className="hidden lg:flex items-center gap-7">
          {NAV_LINKS.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={cn(
                "font-body text-sm font-medium tracking-wide transition-colors relative py-1",
                pathname === link.href
                  ? "text-maroon dark:text-gold-light"
                  : "text-charcoal/80 dark:text-cream/80 hover:text-maroon dark:hover:text-gold-light"
              )}
            >
              {link.label}
              {pathname === link.href && (
                <motion.span
                  layoutId="nav-underline"
                  className="absolute -bottom-1 left-0 right-0 h-0.5 bg-gold rounded-full"
                />
              )}
            </Link>
          ))}
        </div>

        <div className="flex items-center gap-1.5 md:gap-3">
          <ThemeToggle />
          <Link
            href="/products"
            aria-label="Search products"
            className="hidden sm:inline-flex p-2 rounded-full hover:bg-maroon/10 dark:hover:bg-gold/10 transition"
          >
            <Search className="w-5 h-5 text-charcoal dark:text-cream" />
          </Link>
          <button
            aria-label="Wishlist"
            className="hidden sm:inline-flex p-2 rounded-full hover:bg-maroon/10 dark:hover:bg-gold/10 transition"
          >
            <Heart className="w-5 h-5 text-charcoal dark:text-cream" />
          </button>
          <button
            aria-label="Cart"
            onClick={() => setCartOpen(true)}
            className="relative p-2 rounded-full hover:bg-maroon/10 dark:hover:bg-gold/10 transition"
          >
            <ShoppingBag className="w-5 h-5 text-charcoal dark:text-cream" />
            {itemCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 bg-chili text-white text-[10px] font-bold rounded-full w-4 h-4 flex items-center justify-center">
                {itemCount}
              </span>
            )}
          </button>
          <button
            className="lg:hidden p-2 rounded-full hover:bg-maroon/10 dark:hover:bg-gold/10 transition"
            onClick={() => setOpen((v) => !v)}
            aria-label="Toggle menu"
          >
            {open ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </nav>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="lg:hidden overflow-hidden bg-cream dark:bg-charcoal border-t border-gold/20"
          >
            <div className="flex flex-col px-6 py-4 gap-1">
              {NAV_LINKS.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className={cn(
                    "py-3 font-body text-base border-b border-maroon/5 dark:border-cream/5",
                    pathname === link.href
                      ? "text-maroon dark:text-gold-light font-semibold"
                      : "text-charcoal dark:text-cream"
                  )}
                >
                  {link.label}
                </Link>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
