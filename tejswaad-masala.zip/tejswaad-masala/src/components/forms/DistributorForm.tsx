"use client";

import { useState, FormEvent } from "react";
import { CheckCircle2, Loader2 } from "lucide-react";
import Button from "@/components/ui/Button";
import GlassCard from "@/components/ui/GlassCard";

export default function DistributorForm() {
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [form, setForm] = useState({
    fullName: "",
    phone: "",
    email: "",
    city: "",
    state: "Bihar",
    experience: "",
    investmentCapacity: "",
    existingBusiness: "",
    message: "",
  });

  function update<K extends keyof typeof form>(key: K, value: string) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/distributor", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (!res.ok) throw new Error();
      setSubmitted(true);
    } catch {
      setError("Something went wrong. Please try again in a moment.");
    } finally {
      setLoading(false);
    }
  }

  if (submitted) {
    return (
      <GlassCard className="p-10 text-center">
        <CheckCircle2 className="w-12 h-12 text-forest mx-auto mb-4" />
        <h3 className="font-display text-2xl text-maroon dark:text-gold-light mb-2">
          Application Submitted!
        </h3>
        <p className="text-charcoal/70 dark:text-cream/70">
          Thank you for your interest in becoming a Tejswaad Masala distributor. Our team will
          review your application and reach out within 2-3 business days.
        </p>
      </GlassCard>
    );
  }

  return (
    <GlassCard className="p-6 md:p-10">
      <form onSubmit={handleSubmit} className="grid sm:grid-cols-2 gap-5">
        <Field label="Full Name">
          <input required value={form.fullName} onChange={(e) => update("fullName", e.target.value)} className={inputClass} />
        </Field>
        <Field label="Phone Number">
          <input required type="tel" value={form.phone} onChange={(e) => update("phone", e.target.value)} className={inputClass} />
        </Field>
        <Field label="Email (optional)">
          <input type="email" value={form.email} onChange={(e) => update("email", e.target.value)} className={inputClass} />
        </Field>
        <Field label="City">
          <input required value={form.city} onChange={(e) => update("city", e.target.value)} className={inputClass} />
        </Field>
        <Field label="State">
          <input required value={form.state} onChange={(e) => update("state", e.target.value)} className={inputClass} />
        </Field>
        <Field label="Years of Business Experience">
          <input required placeholder="e.g. 5 years in FMCG distribution" value={form.experience} onChange={(e) => update("experience", e.target.value)} className={inputClass} />
        </Field>
        <Field label="Investment Capacity" full>
          <input required placeholder="e.g. ₹2-5 Lakhs" value={form.investmentCapacity} onChange={(e) => update("investmentCapacity", e.target.value)} className={inputClass} />
        </Field>
        <Field label="Existing Business (if any)" full>
          <input value={form.existingBusiness} onChange={(e) => update("existingBusiness", e.target.value)} className={inputClass} />
        </Field>
        <Field label="Message (optional)" full>
          <textarea rows={3} value={form.message} onChange={(e) => update("message", e.target.value)} className={inputClass} />
        </Field>

        {error && <p className="sm:col-span-2 text-sm text-chili">{error}</p>}

        <div className="sm:col-span-2">
          <Button type="submit" size="lg" disabled={loading} className="w-full sm:w-auto">
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Submit Application"}
          </Button>
        </div>
      </form>
    </GlassCard>
  );
}

const inputClass =
  "w-full px-4 py-2.5 rounded-lg bg-white/70 dark:bg-white/5 border border-gold/20 focus:outline-none focus:ring-2 focus:ring-gold text-sm text-charcoal dark:text-cream";

function Field({ label, children, full }: { label: string; children: React.ReactNode; full?: boolean }) {
  return (
    <div className={full ? "sm:col-span-2" : ""}>
      <label className="block text-xs font-semibold text-charcoal/70 dark:text-cream/70 mb-1.5">{label}</label>
      {children}
    </div>
  );
}
