"use client";

import { useState, FormEvent } from "react";
import { CheckCircle2, Loader2, MessageCircle } from "lucide-react";
import Button from "@/components/ui/Button";
import GlassCard from "@/components/ui/GlassCard";
import { whatsappLink } from "@/lib/utils";

const BUSINESS_TYPES = ["Retailer", "Wholesaler", "Restaurant", "Distributor", "Other"];

export default function BulkOrderForm() {
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [form, setForm] = useState({
    businessName: "",
    contactPerson: "",
    phone: "",
    email: "",
    businessType: "Retailer",
    city: "",
    productsInterested: "",
    estimatedQuantity: "",
    message: "",
  });

  function update<K extends keyof typeof form>(key: K, value: string) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/bulk-order", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (!res.ok) throw new Error();
      setSubmitted(true);
    } catch {
      setError("Something went wrong. Please try WhatsApp instead or try again.");
    } finally {
      setLoading(false);
    }
  }

  if (submitted) {
    return (
      <GlassCard className="p-10 text-center">
        <CheckCircle2 className="w-12 h-12 text-forest mx-auto mb-4" />
        <h3 className="font-display text-2xl text-maroon dark:text-gold-light mb-2">
          Inquiry Received!
        </h3>
        <p className="text-charcoal/70 dark:text-cream/70">
          Our team will contact you within 24 hours with a quotation tailored to your business.
        </p>
      </GlassCard>
    );
  }

  return (
    <GlassCard className="p-6 md:p-10">
      <form onSubmit={handleSubmit} className="grid sm:grid-cols-2 gap-5">
        <Field label="Business Name">
          <input
            required
            value={form.businessName}
            onChange={(e) => update("businessName", e.target.value)}
            className={inputClass}
          />
        </Field>
        <Field label="Contact Person">
          <input
            required
            value={form.contactPerson}
            onChange={(e) => update("contactPerson", e.target.value)}
            className={inputClass}
          />
        </Field>
        <Field label="Phone Number">
          <input
            required
            type="tel"
            value={form.phone}
            onChange={(e) => update("phone", e.target.value)}
            className={inputClass}
          />
        </Field>
        <Field label="Email (optional)">
          <input
            type="email"
            value={form.email}
            onChange={(e) => update("email", e.target.value)}
            className={inputClass}
          />
        </Field>
        <Field label="Business Type">
          <select
            value={form.businessType}
            onChange={(e) => update("businessType", e.target.value)}
            className={inputClass}
          >
            {BUSINESS_TYPES.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>
        </Field>
        <Field label="City">
          <input
            required
            value={form.city}
            onChange={(e) => update("city", e.target.value)}
            className={inputClass}
          />
        </Field>
        <Field label="Products Interested In" full>
          <input
            required
            placeholder="e.g. Haldi Powder, Garam Masala, Chicken Masala"
            value={form.productsInterested}
            onChange={(e) => update("productsInterested", e.target.value)}
            className={inputClass}
          />
        </Field>
        <Field label="Estimated Monthly Quantity">
          <input
            required
            placeholder="e.g. 50kg, 200kg"
            value={form.estimatedQuantity}
            onChange={(e) => update("estimatedQuantity", e.target.value)}
            className={inputClass}
          />
        </Field>
        <Field label="Message (optional)" full>
          <textarea
            rows={3}
            value={form.message}
            onChange={(e) => update("message", e.target.value)}
            className={inputClass}
          />
        </Field>

        {error && <p className="sm:col-span-2 text-sm text-chili">{error}</p>}

        <p className="sm:col-span-2 text-xs text-charcoal/50 dark:text-cream/50">
          Minimum order quantity for bulk pricing: 10kg per product category.
        </p>

        <div className="sm:col-span-2 flex flex-col sm:flex-row gap-3">
          <Button type="submit" size="lg" disabled={loading} className="flex-1">
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Request Quotation"}
          </Button>
          <a
            href={whatsappLink("Hi, I'd like to place a bulk order inquiry for Tejswaad Masala products.")}
            target="_blank"
            rel="noopener noreferrer"
            className="flex-1"
          >
            <Button type="button" size="lg" variant="outline" className="w-full">
              <MessageCircle className="w-4 h-4" /> Inquire on WhatsApp
            </Button>
          </a>
        </div>
      </form>
    </GlassCard>
  );
}

const inputClass =
  "w-full px-4 py-2.5 rounded-lg bg-white/70 dark:bg-white/5 border border-gold/20 focus:outline-none focus:ring-2 focus:ring-gold text-sm text-charcoal dark:text-cream";

function Field({
  label,
  children,
  full,
}: {
  label: string;
  children: React.ReactNode;
  full?: boolean;
}) {
  return (
    <div className={full ? "sm:col-span-2" : ""}>
      <label className="block text-xs font-semibold text-charcoal/70 dark:text-cream/70 mb-1.5">
        {label}
      </label>
      {children}
    </div>
  );
}
