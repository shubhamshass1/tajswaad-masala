"use client";

import { useState, FormEvent } from "react";
import { CheckCircle2, Loader2, Star } from "lucide-react";
import Button from "@/components/ui/Button";
import GlassCard from "@/components/ui/GlassCard";

export default function ReviewForm() {
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [rating, setRating] = useState(5);
  const [hoverRating, setHoverRating] = useState(0);
  const [form, setForm] = useState({ name: "", location: "", message: "" });

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/testimonials", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, rating }),
      });
      if (!res.ok) throw new Error();
      setSubmitted(true);
    } catch {
      setError("Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  if (submitted) {
    return (
      <GlassCard className="p-8 text-center">
        <CheckCircle2 className="w-10 h-10 text-forest mx-auto mb-3" />
        <h3 className="font-display text-xl text-maroon dark:text-gold-light mb-1">
          Thank you for your review!
        </h3>
        <p className="text-sm text-charcoal/70 dark:text-cream/70">
          It will appear on this page once approved by our team.
        </p>
      </GlassCard>
    );
  }

  return (
    <GlassCard className="p-6 md:p-8">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="flex justify-center gap-1">
          {Array.from({ length: 5 }).map((_, i) => (
            <button
              type="button"
              key={i}
              onMouseEnter={() => setHoverRating(i + 1)}
              onMouseLeave={() => setHoverRating(0)}
              onClick={() => setRating(i + 1)}
              aria-label={`Rate ${i + 1} stars`}
            >
              <Star
                className="w-8 h-8"
                fill={i < (hoverRating || rating) ? "#C9A227" : "none"}
                color="#C9A227"
              />
            </button>
          ))}
        </div>
        <div className="grid sm:grid-cols-2 gap-4">
          <input
            required
            placeholder="Your Name"
            value={form.name}
            onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
            className={inputClass}
          />
          <input
            placeholder="City (optional)"
            value={form.location}
            onChange={(e) => setForm((f) => ({ ...f, location: e.target.value }))}
            className={inputClass}
          />
        </div>
        <textarea
          required
          rows={4}
          placeholder="Tell us about your experience with Tejswaad Masala..."
          value={form.message}
          onChange={(e) => setForm((f) => ({ ...f, message: e.target.value }))}
          className={inputClass}
        />
        {error && <p className="text-sm text-chili">{error}</p>}
        <Button type="submit" size="lg" disabled={loading} className="w-full">
          {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Submit Review"}
        </Button>
      </form>
    </GlassCard>
  );
}

const inputClass =
  "w-full px-4 py-2.5 rounded-lg bg-white/70 dark:bg-white/5 border border-gold/20 focus:outline-none focus:ring-2 focus:ring-gold text-sm text-charcoal dark:text-cream";
