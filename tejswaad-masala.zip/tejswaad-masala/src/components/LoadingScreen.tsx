"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

const SPICES = [
  { emoji: "🌶️", color: "#C1272D" },
  { emoji: "🟡", color: "#E08B1D" },
  { emoji: "🍃", color: "#163A1F" },
  { emoji: "⭐", color: "#C9A227" },
];

export default function LoadingScreen() {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 1800);
    return () => clearTimeout(t);
  }, []);

  return (
    <AnimatePresence>
      {loading && (
        <motion.div
          exit={{ opacity: 0, transition: { duration: 0.6, ease: "easeInOut" } }}
          className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-maroon-dark"
        >
          <div className="relative w-28 h-28 mb-8">
            {SPICES.map((s, i) => (
              <motion.span
                key={i}
                className="absolute inset-0 flex items-center justify-center text-4xl"
                style={{ transformOrigin: "50% 50%" }}
                animate={{ rotate: 360 }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  ease: "linear",
                  delay: i * 0.15,
                }}
              >
                <span
                  style={{
                    transform: `rotate(${i * 90}deg) translate(48px) rotate(${-i * 90}deg)`,
                  }}
                >
                  {s.emoji}
                </span>
              </motion.span>
            ))}
            <motion.div
              animate={{ scale: [1, 1.08, 1] }}
              transition={{ duration: 1.4, repeat: Infinity }}
              className="absolute inset-0 flex items-center justify-center"
            >
              <div className="w-14 h-14 rounded-full bg-gold-shimmer bg-[length:200%_100%] animate-shimmer shadow-gold" />
            </motion.div>
          </div>
          <motion.h1
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="font-display text-2xl md:text-3xl text-cream tracking-wide"
          >
            Tejswaad Masala
          </motion.h1>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="font-accent italic text-gold-light mt-2"
          >
            Ghar Jaisa Taste
          </motion.p>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
