"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Star, Quote, ChevronLeft, ChevronRight } from "lucide-react";
import SectionHeading from "@/components/ui/SectionHeading";
import { testimonials } from "@/lib/data/testimonials";

export default function TestimonialSlider() {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setIndex((i) => (i + 1) % testimonials.length), 5500);
    return () => clearInterval(t);
  }, []);

  const current = testimonials[index];

  return (
    <section className="py-24 bg-cream-dark/40 dark:bg-[#1a1108]">
      <div className="mx-auto max-w-3xl px-6 md:px-8 text-center">
        <SectionHeading eyebrow="Testimonials" title="What Our Customers Say" />
        <div className="relative min-h-[220px] flex items-center justify-center">
          <Quote className="absolute top-0 left-1/2 -translate-x-1/2 w-10 h-10 text-gold/30" />
          <AnimatePresence mode="wait">
            <motion.div
              key={current._id}
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -30 }}
              transition={{ duration: 0.4 }}
              className="pt-8"
            >
              <div className="flex justify-center gap-1 mb-4">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star
                    key={i}
                    className="w-4 h-4"
                    fill={i < current.rating ? "#C9A227" : "none"}
                    color="#C9A227"
                  />
                ))}
              </div>
              <p className="font-accent italic text-lg md:text-xl text-charcoal dark:text-cream leading-relaxed">
                "{current.message}"
              </p>
              <p className="mt-5 font-display text-maroon dark:text-gold-light">
                {current.name}
              </p>
              <p className="text-xs text-charcoal/50 dark:text-cream/50">{current.location}</p>
            </motion.div>
          </AnimatePresence>
        </div>

        <div className="flex items-center justify-center gap-4 mt-6">
          <button
            aria-label="Previous testimonial"
            onClick={() => setIndex((i) => (i - 1 + testimonials.length) % testimonials.length)}
            className="w-9 h-9 rounded-full border border-gold/30 flex items-center justify-center hover:bg-gold/10 transition"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          {testimonials.map((_, i) => (
            <button
              key={i}
              onClick={() => setIndex(i)}
              aria-label={`Go to testimonial ${i + 1}`}
              className={`w-2 h-2 rounded-full transition-all ${
                i === index ? "bg-maroon dark:bg-gold-light w-5" : "bg-charcoal/20 dark:bg-cream/20"
              }`}
            />
          ))}
          <button
            aria-label="Next testimonial"
            onClick={() => setIndex((i) => (i + 1) % testimonials.length)}
            className="w-9 h-9 rounded-full border border-gold/30 flex items-center justify-center hover:bg-gold/10 transition"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </section>
  );
}
