"use client";

import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import { RoundedBox, Text, Float } from "@react-three/drei";
import * as THREE from "three";

/**
 * A stylised 3D spice pouch/box rendered with primitive geometry (no external
 * model file needed — keeps the bundle light and the build dependency-free).
 * Colours are pulled directly from the Tejswaad brand palette.
 */
export default function SpicePacket3D() {
  const group = useRef<THREE.Group>(null);

  useFrame((_, delta) => {
    if (group.current) {
      group.current.rotation.y += delta * 0.4;
    }
  });

  return (
    <Float speed={1.4} rotationIntensity={0.3} floatIntensity={0.6}>
      <group ref={group}>
        {/* Main pouch body */}
        <RoundedBox args={[1.6, 2.1, 0.45]} radius={0.08} smoothness={4}>
          <meshStandardMaterial color="#8B0F13" roughness={0.35} metalness={0.15} />
        </RoundedBox>

        {/* Gold trim band */}
        <mesh position={[0, 0.55, 0.226]}>
          <planeGeometry args={[1.45, 0.32]} />
          <meshStandardMaterial color="#C9A227" roughness={0.3} metalness={0.6} />
        </mesh>

        {/* Brand label */}
        <Text
          position={[0, 0.55, 0.23]}
          fontSize={0.16}
          color="#3a1a05"
          anchorX="center"
          anchorY="middle"
          maxWidth={1.3}
        >
          Tejswaad
        </Text>

        <Text
          position={[0, -0.05, 0.226]}
          fontSize={0.1}
          color="#F8EEDD"
          anchorX="center"
          anchorY="middle"
          maxWidth={1.2}
        >
          MASALA
        </Text>

        <Text
          position={[0, -0.32, 0.226]}
          fontSize={0.065}
          color="#E8C874"
          anchorX="center"
          anchorY="middle"
          maxWidth={1.2}
          fontStyle="italic"
        >
          Ghar Jaisa Taste
        </Text>

        {/* Bottom seal fold */}
        <mesh position={[0, -1.02, 0]}>
          <boxGeometry args={[1.6, 0.14, 0.46]} />
          <meshStandardMaterial color="#5C0A0D" roughness={0.5} />
        </mesh>

        {/* Top seal fold */}
        <mesh position={[0, 1.05, 0]} rotation={[0, 0, 0]}>
          <boxGeometry args={[1.6, 0.1, 0.46]} />
          <meshStandardMaterial color="#5C0A0D" roughness={0.5} />
        </mesh>
      </group>
    </Float>
  );
}
