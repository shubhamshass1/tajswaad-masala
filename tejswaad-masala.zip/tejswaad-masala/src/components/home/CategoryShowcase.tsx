import Link from "next/link";
import SectionHeading from "@/components/ui/SectionHeading";
import RevealOnScroll from "@/components/ui/RevealOnScroll";
import { categories } from "@/lib/data/products";

const CATEGORY_ICONS: Record<string, string> = {
  "Haldi Powder": "🟡",
  "Mirchi Powder": "🌶️",
  "Dhaniya Powder": "🌿",
  "Garam Masala": "✨",
  "Kitchen King Masala": "👑",
  "Jeera Powder": "🟤",
  "Sabzi Masala": "🥘",
  "Chaat Masala": "🍋",
  "Meat Masala": "🍖",
  "Chicken Masala": "🍗",
  "Khada Garam Masala": "🌰",
  "Other Spices": "🧂",
};

export default function CategoryShowcase() {
  const list = categories.filter((c) => c !== "All");
  return (
    <section className="py-24 bg-cream-dark/40 dark:bg-[#1a1108]">
      <div className="mx-auto max-w-7xl px-6 md:px-8">
        <SectionHeading
          eyebrow="Our Range"
          title="Every Spice Your Kitchen Needs"
          description="Twelve categories of pure, fresh-ground masalas — from everyday essentials to specialty blends."
        />
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
          {list.map((cat, i) => (
            <RevealOnScroll key={cat} delay={i * 0.05}>
              <Link
                href={`/products?category=${encodeURIComponent(cat)}`}
                className="group flex flex-col items-center justify-center text-center gap-3 p-6 rounded-2xl bg-white/70 dark:bg-white/5 border border-gold/20 shadow-glass hover:shadow-premium hover:-translate-y-1.5 hover:border-gold/50 transition-all duration-300"
              >
                <span className="text-4xl group-hover:scale-110 transition-transform duration-300">
                  {CATEGORY_ICONS[cat] ?? "🧂"}
                </span>
                <span className="font-body text-sm font-medium text-charcoal dark:text-cream">
                  {cat}
                </span>
              </Link>
            </RevealOnScroll>
          ))}
        </div>
      </div>
    </section>
  );
}
