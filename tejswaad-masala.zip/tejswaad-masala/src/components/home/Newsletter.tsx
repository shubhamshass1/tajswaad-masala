"use client";

import { useState, FormEvent } from "react";
import { Mail, CheckCircle2 } from "lucide-react";
import Button from "@/components/ui/Button";

export default function Newsletter() {
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      await fetch("/api/newsletter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
    } catch {
      // fail silently in UI; could surface a toast in a fuller build
    } finally {
      setLoading(false);
      setSubmitted(true);
    }
  }

  return (
    <section className="py-20 bg-forest text-cream">
      <div className="mx-auto max-w-2xl px-6 text-center">
        <Mail className="w-9 h-9 mx-auto text-gold-light mb-4" />
        <h2 className="font-display text-2xl md:text-3xl mb-2">Stay Updated with Tejswaad</h2>
        <p className="text-cream/70 mb-8">
          Get notified about new products, festive offers and bulk pricing updates.
        </p>
        {submitted ? (
          <p className="flex items-center justify-center gap-2 text-gold-light font-medium">
            <CheckCircle2 className="w-5 h-5" /> Thanks! You're subscribed.
          </p>
        ) : (
          <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
            <input
              required
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email"
              className="flex-1 px-5 py-3 rounded-full bg-white/10 border border-cream/20 placeholder:text-cream/40 focus:outline-none focus:ring-2 focus:ring-gold"
            />
            <Button type="submit" variant="secondary" disabled={loading}>
              {loading ? "Subscribing..." : "Subscribe"}
            </Button>
          </form>
        )}
      </div>
    </section>
  );
}
