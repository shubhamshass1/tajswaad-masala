"use client";

import dynamic from "next/dynamic";
import Link from "next/link";
import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import { ArrowRight, Package, MessageCircle } from "lucide-react";
import Button from "@/components/ui/Button";
import { whatsappLink } from "@/lib/utils";

const Hero3D = dynamic(() => import("./Hero3D"), { ssr: false });

export default function HeroSection() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], [0, 120]);
  const opacity = useTransform(scrollYProgress, [0, 0.8], [1, 0]);

  return (
    <section
      ref={ref}
      className="relative min-h-[100svh] flex items-center overflow-hidden bg-gradient-to-b from-cream via-cream to-cream-dark dark:from-charcoal dark:via-charcoal dark:to-[#150e08]"
    >
      {/* Ambient background texture */}
      <div
        className="absolute inset-0 opacity-[0.08] pointer-events-none"
        style={{
          backgroundImage:
            "radial-gradient(circle at 15% 25%, #8B0F13 0, transparent 35%), radial-gradient(circle at 85% 15%, #E08B1D 0, transparent 30%), radial-gradient(circle at 75% 85%, #163A1F 0, transparent 35%)",
        }}
      />

      <div className="relative mx-auto max-w-7xl w-full px-6 md:px-8 grid grid-cols-1 lg:grid-cols-2 gap-10 items-center pt-28 pb-16 lg:py-0">
        <motion.div style={{ y, opacity }} className="text-center lg:text-left order-2 lg:order-1">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-forest/10 dark:bg-gold/10 text-forest dark:text-gold-light text-xs font-semibold tracking-wider uppercase mb-6"
          >
            <Package className="w-3.5 h-3.5" /> Manufacturer &amp; Supplier of Pure Spices
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="font-display text-4xl sm:text-5xl lg:text-6xl leading-[1.1] text-maroon dark:text-cream"
          >
            Tejswaad Masala
            <span className="block font-accent italic text-gold-dark dark:text-gold-light text-3xl sm:text-4xl lg:text-5xl mt-2">
              Ghar Jaisa Taste
            </span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="mt-6 text-lg text-charcoal/75 dark:text-cream/75 max-w-xl mx-auto lg:mx-0"
          >
            Pure, Fresh and Authentic Indian Spices — stone-ground in small batches and
            delivered straight from Begusarai, Bihar to your kitchen.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="mt-9 flex flex-wrap gap-4 justify-center lg:justify-start"
          >
            <Link href="/products">
              <Button size="lg">
                Explore Products <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
            <a href={whatsappLink("Hi, I would like to place an order for Tejswaad Masala.")} target="_blank" rel="noopener noreferrer">
              <Button size="lg" variant="secondary">
                Order Now <MessageCircle className="w-4 h-4" />
              </Button>
            </a>
            <Link href="/bulk-order">
              <Button size="lg" variant="outline">
                Bulk Order
              </Button>
            </Link>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            className="mt-10 flex items-center gap-6 justify-center lg:justify-start text-sm text-charcoal/60 dark:text-cream/60"
          >
            <span>✓ FSSAI Certified</span>
            <span>✓ 100% Natural</span>
            <span>✓ Pan-India Delivery</span>
          </motion.div>
        </motion.div>

        <div className="relative h-[340px] sm:h-[420px] lg:h-[560px] order-1 lg:order-2">
          <Hero3D />
        </div>
      </div>

      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 hidden sm:flex flex-col items-center gap-2 text-charcoal/40 dark:text-cream/40">
        <span className="text-[11px] tracking-widest uppercase">Scroll</span>
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ repeat: Infinity, duration: 1.6 }}
          className="w-px h-8 bg-current"
        />
      </div>
    </section>
  );
}
