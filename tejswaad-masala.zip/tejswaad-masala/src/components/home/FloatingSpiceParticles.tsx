"use client";

import { useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";

type Particle = {
  position: [number, number, number];
  scale: number;
  speed: number;
  color: string;
  shape: "sphere" | "capsule";
};

const COLORS = {
  turmeric: "#E08B1D",
  chili: "#C1272D",
  coriander: "#C9A227",
  cumin: "#6B4A1E",
};

function makeParticles(count: number): Particle[] {
  const colors = Object.values(COLORS);
  const shapes: Particle["shape"][] = ["sphere", "capsule"];
  return Array.from({ length: count }).map((_, i) => ({
    position: [
      (Math.random() - 0.5) * 8,
      (Math.random() - 0.5) * 5,
      (Math.random() - 0.5) * 4 - 1,
    ],
    scale: 0.05 + Math.random() * 0.09,
    speed: 0.2 + Math.random() * 0.5,
    color: colors[i % colors.length],
    shape: shapes[i % shapes.length],
  }));
}

export default function FloatingSpiceParticles({ count = 40 }: { count?: number }) {
  const particles = useMemo(() => makeParticles(count), [count]);
  const group = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (!group.current) return;
    group.current.children.forEach((mesh, i) => {
      const p = particles[i];
      mesh.position.y += Math.sin(state.clock.elapsedTime * p.speed + i) * 0.0025;
      mesh.rotation.x += 0.003;
      mesh.rotation.y += 0.004;
    });
  });

  return (
    <group ref={group}>
      {particles.map((p, i) => (
        <mesh key={i} position={p.position} scale={p.scale}>
          {p.shape === "sphere" ? (
            <sphereGeometry args={[1, 8, 8]} />
          ) : (
            <capsuleGeometry args={[0.5, 1, 4, 8]} />
          )}
          <meshStandardMaterial color={p.color} roughness={0.6} />
        </mesh>
      ))}
    </group>
  );
}
