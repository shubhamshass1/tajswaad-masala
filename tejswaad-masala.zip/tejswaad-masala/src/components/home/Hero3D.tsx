"use client";

import { Suspense } from "react";
import { Canvas } from "@react-three/fiber";
import { Environment, ContactShadows } from "@react-three/drei";
import SpicePacket3D from "./SpicePacket3D";
import FloatingSpiceParticles from "./FloatingSpiceParticles";

export default function Hero3D() {
  return (
    <div className="absolute inset-0">
      <Canvas
        camera={{ position: [0, 0, 5.2], fov: 42 }}
        dpr={[1, 1.5]}
        gl={{ alpha: true, antialias: true }}
      >
        <ambientLight intensity={0.7} />
        <directionalLight position={[3, 4, 5]} intensity={1.4} color="#FFE9C4" />
        <directionalLight position={[-4, -2, -3]} intensity={0.4} color="#C9A227" />

        <Suspense fallback={null}>
          <SpicePacket3D />
          <FloatingSpiceParticles count={36} />
          <ContactShadows position={[0, -1.6, 0]} opacity={0.35} scale={8} blur={2.6} far={2} />
          <Environment preset="apartment" />
        </Suspense>
      </Canvas>
    </div>
  );
}
