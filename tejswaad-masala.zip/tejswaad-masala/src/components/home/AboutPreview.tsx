import Image from "next/image";
import Link from "next/link";
import { ArrowRight, Leaf, ShieldCheck, Users } from "lucide-react";
import SectionHeading from "@/components/ui/SectionHeading";
import RevealOnScroll from "@/components/ui/RevealOnScroll";
import Button from "@/components/ui/Button";

const POINTS = [
  { icon: Leaf, title: "100% Natural", text: "No artificial colours or fillers — ever." },
  { icon: ShieldCheck, title: "FSSAI Certified", text: "Fully licensed manufacturing (2655816159996187)." },
  { icon: Users, title: "Family Owned", text: "Run by Neeraj Kumar, rooted in Begusarai, Bihar." },
];

export default function AboutPreview() {
  return (
    <section className="py-24 bg-cream dark:bg-charcoal">
      <div className="mx-auto max-w-7xl px-6 md:px-8 grid grid-cols-1 lg:grid-cols-2 gap-14 items-center">
        <RevealOnScroll>
          <div className="relative rounded-3xl overflow-hidden shadow-premium aspect-[4/5] max-w-md mx-auto lg:mx-0">
            <Image
              src="/images/products/spices-collage.jpg"
              alt="Fresh whole and ground spices from Tejswaad Masala"
              fill
              className="object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-maroon-dark/50 to-transparent" />
          </div>
        </RevealOnScroll>

        <RevealOnScroll delay={0.15}>
          <SectionHeading
            eyebrow="Our Story"
            title="Rooted in tradition, ground fresh every day"
            align="left"
          />
          <p className="text-charcoal/75 dark:text-cream/75 leading-relaxed mb-6 -mt-6">
            Tejswaad Masala began as a small family kitchen in Kiul, Begusarai — grinding spices
            the way our grandmothers did, in small batches, with whole ingredients and patience.
            Today we manufacture and supply pure, fresh spices to homes and businesses across
            Bihar, without losing that ghar jaisa care in every packet.
          </p>
          <div className="grid sm:grid-cols-3 gap-4 mb-8">
            {POINTS.map((p) => (
              <div key={p.title} className="p-4 rounded-xl bg-white/60 dark:bg-white/5 border border-gold/20">
                <p.icon className="w-6 h-6 text-maroon dark:text-gold-light mb-2" />
                <h4 className="font-display text-sm text-charcoal dark:text-cream mb-1">{p.title}</h4>
                <p className="text-xs text-charcoal/60 dark:text-cream/60">{p.text}</p>
              </div>
            ))}
          </div>
          <Link href="/about">
            <Button variant="outline">
              Read Our Full Story <ArrowRight className="w-4 h-4" />
            </Button>
          </Link>
        </RevealOnScroll>
      </div>
    </section>
  );
}
