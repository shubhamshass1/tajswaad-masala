import Link from "next/link";
import SectionHeading from "@/components/ui/SectionHeading";
import RevealOnScroll from "@/components/ui/RevealOnScroll";
import ProductCard from "@/components/products/ProductCard";
import Button from "@/components/ui/Button";
import { products } from "@/lib/data/products";

export default function BestSellers() {
  const bestSellers = products.filter((p) => p.isBestSeller).slice(0, 4);
  return (
    <section className="py-24 bg-cream dark:bg-charcoal">
      <div className="mx-auto max-w-7xl px-6 md:px-8">
        <SectionHeading
          eyebrow="Customer Favourites"
          title="Our Best Selling Masalas"
          description="The blends our customers reorder again and again."
        />
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
          {bestSellers.map((p, i) => (
            <RevealOnScroll key={p._id} delay={i * 0.08}>
              <ProductCard product={p} />
            </RevealOnScroll>
          ))}
        </div>
        <div className="text-center mt-12">
          <Link href="/products">
            <Button variant="outline" size="lg">
              View All Products
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}
