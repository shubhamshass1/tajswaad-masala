import Link from "next/link";
import { ArrowRight, Building2 } from "lucide-react";
import Button from "@/components/ui/Button";
import RevealOnScroll from "@/components/ui/RevealOnScroll";

export default function CTASection() {
  return (
    <section className="py-20 bg-cream dark:bg-charcoal">
      <div className="mx-auto max-w-6xl px-6 md:px-8">
        <RevealOnScroll>
          <div className="relative rounded-3xl bg-gold-shimmer bg-[length:200%_100%] animate-shimmer p-[1.5px] shadow-gold">
            <div className="rounded-[calc(1.5rem-1.5px)] bg-maroon-dark px-8 py-14 text-center relative overflow-hidden">
              <Building2 className="w-10 h-10 text-gold-light mx-auto mb-4" />
              <h2 className="font-display text-2xl md:text-4xl text-cream mb-3">
                Retailer, Restaurant or Distributor?
              </h2>
              <p className="text-cream/70 max-w-xl mx-auto mb-8">
                Get wholesale pricing, dedicated support and reliable bulk supply of every
                Tejswaad spice, delivered straight to your business.
              </p>
              <Link href="/bulk-order">
                <Button size="lg" variant="secondary">
                  Request Bulk Pricing <ArrowRight className="w-4 h-4" />
                </Button>
              </Link>
            </div>
          </div>
        </RevealOnScroll>
      </div>
    </section>
  );
}
