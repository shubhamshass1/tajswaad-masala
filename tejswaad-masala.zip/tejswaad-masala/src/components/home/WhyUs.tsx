import { Sparkles, Factory, Truck, Award } from "lucide-react";
import SectionHeading from "@/components/ui/SectionHeading";
import RevealOnScroll from "@/components/ui/RevealOnScroll";
import ArchDivider from "@/components/layout/ArchDivider";

const REASONS = [
  {
    icon: Sparkles,
    title: "100% Natural & Pure",
    text: "No artificial colours, no fillers — just real spices, ground fresh.",
  },
  {
    icon: Factory,
    title: "Own Manufacturing Unit",
    text: "Every batch is processed and packed at our Begusarai facility.",
  },
  {
    icon: Award,
    title: "FSSAI Licensed",
    text: "Fully certified and compliant (License No. 2655816159996187).",
  },
  {
    icon: Truck,
    title: "Reliable Supply",
    text: "Consistent quality for households, retailers and restaurants alike.",
  },
];

export default function WhyUs() {
  return (
    <section className="relative bg-maroon text-cream">
      <ArchDivider fill="text-cream dark:text-charcoal" />
      <div className="mx-auto max-w-7xl px-6 md:px-8 pb-24 -mt-4">
        <SectionHeading
          eyebrow="Why Tejswaad"
          title="Trusted for the Same Reasons, Every Time"
          light
        />
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {REASONS.map((r, i) => (
            <RevealOnScroll key={r.title} delay={i * 0.1}>
              <div className="h-full p-6 rounded-2xl bg-white/5 border border-gold/20 backdrop-blur-sm hover:bg-white/10 transition-colors">
                <r.icon className="w-8 h-8 text-gold-light mb-4" />
                <h3 className="font-display text-lg mb-2">{r.title}</h3>
                <p className="text-sm text-cream/70 leading-relaxed">{r.text}</p>
              </div>
            </RevealOnScroll>
          ))}
        </div>
      </div>
    </section>
  );
}
