import { cn } from "@/lib/utils";

export function StatCard({
  label,
  value,
  icon: Icon,
}: {
  label: string;
  value: string | number;
  icon: React.ComponentType<{ className?: string }>;
}) {
  return (
    <div className="p-5 rounded-2xl bg-white border border-gold/20 shadow-sm">
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs font-semibold uppercase tracking-wide text-charcoal/50">
          {label}
        </span>
        <Icon className="w-4 h-4 text-maroon" />
      </div>
      <p className="font-display text-2xl text-charcoal">{value}</p>
    </div>
  );
}

export function StatusBadge({ status }: { status: string }) {
  const colorMap: Record<string, string> = {
    Pending: "bg-yellow-100 text-yellow-700",
    Confirmed: "bg-blue-100 text-blue-700",
    Packed: "bg-indigo-100 text-indigo-700",
    Shipped: "bg-purple-100 text-purple-700",
    Delivered: "bg-green-100 text-green-700",
    Cancelled: "bg-red-100 text-red-700",
    New: "bg-yellow-100 text-yellow-700",
    Contacted: "bg-blue-100 text-blue-700",
    Quoted: "bg-indigo-100 text-indigo-700",
    Closed: "bg-green-100 text-green-700",
    Reviewing: "bg-blue-100 text-blue-700",
    Approved: "bg-green-100 text-green-700",
    Rejected: "bg-red-100 text-red-700",
    Paid: "bg-green-100 text-green-700",
    Failed: "bg-red-100 text-red-700",
  };
  return (
    <span
      className={cn(
        "px-2.5 py-1 rounded-full text-xs font-semibold",
        colorMap[status] ?? "bg-gray-100 text-gray-700"
      )}
    >
      {status}
    </span>
  );
}

export function AdminCard({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={cn("bg-white rounded-2xl border border-gold/20 shadow-sm", className)}>
      {children}
    </div>
  );
}

export function PageHeader({ title, description }: { title: string; description?: string }) {
  return (
    <div className="mb-6">
      <h1 className="font-display text-2xl md:text-3xl text-maroon">{title}</h1>
      {description && <p className="text-sm text-charcoal/60 mt-1">{description}</p>}
    </div>
  );
}
