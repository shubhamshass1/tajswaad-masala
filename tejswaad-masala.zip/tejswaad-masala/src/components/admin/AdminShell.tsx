"use client";

import { usePathname } from "next/navigation";
import Link from "next/link";
import Image from "next/image";
import { signOut, useSession } from "next-auth/react";
import {
  LayoutDashboard,
  Package,
  ShoppingCart,
  Building2,
  Users,
  MessageSquare,
  Star,
  ImageIcon,
  Mail,
  Settings,
  LogOut,
  Menu,
} from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";

const LINKS = [
  { href: "/admin", label: "Dashboard", icon: LayoutDashboard },
  { href: "/admin/products", label: "Products", icon: Package },
  { href: "/admin/orders", label: "Orders", icon: ShoppingCart },
  { href: "/admin/bulk-orders", label: "Bulk Orders", icon: Building2 },
  { href: "/admin/distributors", label: "Distributors", icon: Users },
  { href: "/admin/messages", label: "Messages", icon: Mail },
  { href: "/admin/testimonials", label: "Testimonials", icon: Star },
  { href: "/admin/gallery", label: "Gallery", icon: ImageIcon },
  { href: "/admin/settings", label: "Settings", icon: Settings },
];

export default function AdminShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const { data: session } = useSession();
  const [open, setOpen] = useState(false);

  if (pathname === "/admin/login") return <>{children}</>;

  return (
    <div className="min-h-screen flex bg-cream-dark/30">
      {/* Sidebar */}
      <aside
        className={cn(
          "fixed lg:static inset-y-0 left-0 z-40 w-64 bg-maroon-dark text-cream flex flex-col transition-transform lg:translate-x-0",
          open ? "translate-x-0" : "-translate-x-full"
        )}
      >
        <div className="p-5 border-b border-cream/10">
          <Image src="/images/logo.png" alt="Tejswaad Masala" width={140} height={66} className="h-10 w-auto object-contain brightness-0 invert" />
          <p className="text-[11px] text-cream/50 mt-2 uppercase tracking-widest">Owner Admin Panel</p>
        </div>
        <nav className="flex-1 overflow-y-auto py-4">
          {LINKS.map((link) => {
            const active = pathname === link.href;
            return (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => setOpen(false)}
                className={cn(
                  "flex items-center gap-3 px-5 py-3 text-sm transition-colors",
                  active
                    ? "bg-gold/15 text-gold-light border-r-2 border-gold-light"
                    : "text-cream/70 hover:bg-white/5 hover:text-cream"
                )}
              >
                <link.icon className="w-4 h-4" /> {link.label}
              </Link>
            );
          })}
        </nav>
        <div className="p-5 border-t border-cream/10">
          <p className="text-xs text-cream/50 mb-2 truncate">{session?.user?.email}</p>
          <button
            onClick={() => signOut({ callbackUrl: "/admin/login" })}
            className="flex items-center gap-2 text-sm text-cream/70 hover:text-gold-light"
          >
            <LogOut className="w-4 h-4" /> Sign Out
          </button>
        </div>
      </aside>

      {open && (
        <div className="fixed inset-0 bg-black/40 z-30 lg:hidden" onClick={() => setOpen(false)} />
      )}

      {/* Main content */}
      <div className="flex-1 min-w-0">
        <header className="lg:hidden sticky top-0 z-20 bg-cream flex items-center justify-between px-4 py-3 border-b border-gold/20">
          <Image src="/images/logo.png" alt="Tejswaad Masala" width={100} height={48} className="h-8 w-auto object-contain" />
          <button onClick={() => setOpen(true)} aria-label="Open menu">
            <Menu className="w-6 h-6 text-maroon" />
          </button>
        </header>
        <main className="p-4 md:p-8 max-w-6xl mx-auto">{children}</main>
      </div>
    </div>
  );
}
