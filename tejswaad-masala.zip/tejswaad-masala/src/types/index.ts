export type WeightOption = {
  weight: string; // e.g. "100g", "250g", "500g", "1kg"
  price: number; // in INR
  mrp?: number; // optional strike-through price
  stock: number;
};

export type Product = {
  _id: string;
  slug: string;
  name: string;
  category: ProductCategory;
  description: string;
  shortDescription: string;
  images: string[];
  weightOptions: WeightOption[];
  isBestSeller?: boolean;
  isNew?: boolean;
  rating?: number;
  reviewCount?: number;
  ingredients?: string[];
  isActive: boolean;
  createdAt?: string;
  updatedAt?: string;
};

export type ProductCategory =
  | "Haldi Powder"
  | "Mirchi Powder"
  | "Dhaniya Powder"
  | "Garam Masala"
  | "Kitchen King Masala"
  | "Jeera Powder"
  | "Sabzi Masala"
  | "Chaat Masala"
  | "Meat Masala"
  | "Chicken Masala"
  | "Khada Garam Masala"
  | "Other Spices";

export type CartItem = {
  productId: string;
  slug: string;
  name: string;
  image: string;
  weight: string;
  price: number;
  quantity: number;
};

export type OrderStatus =
  | "Pending"
  | "Confirmed"
  | "Packed"
  | "Shipped"
  | "Delivered"
  | "Cancelled";

export type PaymentMethod = "COD" | "Razorpay";

export type Order = {
  _id: string;
  orderNumber: string;
  customer: {
    name: string;
    phone: string;
    email?: string;
    address: string;
    city: string;
    state: string;
    pincode: string;
  };
  items: CartItem[];
  subtotal: number;
  shipping: number;
  total: number;
  paymentMethod: PaymentMethod;
  paymentStatus: "Pending" | "Paid" | "Failed";
  razorpayOrderId?: string;
  razorpayPaymentId?: string;
  status: OrderStatus;
  createdAt: string;
};

export type BulkOrderInquiry = {
  _id: string;
  businessName: string;
  contactPerson: string;
  phone: string;
  email?: string;
  businessType: "Retailer" | "Wholesaler" | "Restaurant" | "Distributor" | "Other";
  city: string;
  productsInterested: string;
  estimatedQuantity: string;
  message?: string;
  status: "New" | "Contacted" | "Quoted" | "Closed";
  createdAt: string;
};

export type DistributorApplication = {
  _id: string;
  fullName: string;
  phone: string;
  email?: string;
  city: string;
  state: string;
  experience: string;
  investmentCapacity: string;
  existingBusiness?: string;
  message?: string;
  status: "New" | "Reviewing" | "Approved" | "Rejected";
  createdAt: string;
};

export type Testimonial = {
  _id: string;
  name: string;
  location?: string;
  rating: number;
  message: string;
  image?: string;
  isApproved: boolean;
  createdAt: string;
};

export type ContactMessage = {
  _id: string;
  name: string;
  email?: string;
  phone: string;
  subject: string;
  message: string;
  isRead: boolean;
  createdAt: string;
};

export type GalleryImage = {
  _id: string;
  url: string;
  caption?: string;
  category: "Spices" | "Factory" | "Packaging" | "Team";
  createdAt: string;
};
